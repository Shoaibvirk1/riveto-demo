<?php
/**
 * Plugin Name:       Store Kit – Site Essentials
 * Description:       Implements the store PRD: one-page COD checkout, Pakistani phone validation, WhatsApp order confirmation text, announcement bar, WhatsApp button, trust strip, size/colour buttons and sticky mobile "Add to cart".
 * Version:           1.2.1
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Text Domain:       store-kit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'STORE_KIT_VERSION', '1.2.1' );
define( 'STORE_KIT_URL', plugin_dir_url( __FILE__ ) );

// Declare compatibility with WooCommerce order storage; the checkout customisations need the classic checkout.
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, false );
	}
} );

final class Store_Kit {

	const OPT = 'store_kit_options';

	/* ------------------------------------------------------------------ *
	 * Settings
	 * ------------------------------------------------------------------ */

	public static function defaults() {
		return array(
			'whatsapp'            => '',
			'whatsapp_message'    => 'Hi! I have a question about my order.',
			'announcement'        => 'Cash on Delivery all over Pakistan | Free delivery on orders over Rs 5,000',
			'delivery_time'       => 'Delivered in 3-5 working days',
			'exchange_text'       => '7-day size exchange',
			'brand_color'         => '#2B59C3',
			'accent_color'        => '#F2762E',
			'f_announcement'      => 1,
			'f_whatsapp_button'   => 1,
			'f_trust_strip'       => 1,
			'f_swatches'          => 1,
			'f_sticky_atc'        => 1,
			'f_simple_checkout'   => 1,
			'f_phone_validation'  => 1,
			'f_free_ship_only'    => 1,
		);
	}

	public static function features() {
		return array(
			'f_announcement'     => 'Announcement bar at the top of every page',
			'f_whatsapp_button'  => 'Floating WhatsApp button',
			'f_trust_strip'      => 'Trust strip under "Add to cart" on product pages',
			'f_swatches'         => 'Size and colour buttons instead of dropdowns',
			'f_sticky_atc'       => 'Sticky "Add to cart" bar on mobile product pages',
			'f_simple_checkout'  => 'Simplified checkout (name, phone, city, address, optional email; COD first)',
			'f_phone_validation' => 'Pakistani mobile number validation at checkout',
			'f_free_ship_only'   => 'When an order qualifies for free shipping, hide the paid delivery options',
		);
	}

	public static function opt( $key ) {
		$o = wp_parse_args( (array) get_option( self::OPT, array() ), self::defaults() );
		return isset( $o[ $key ] ) ? $o[ $key ] : '';
	}

	public static function on( $feature ) {
		return (bool) self::opt( $feature );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'action_links' ) );

		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		add_action( 'admin_notices', array( __CLASS__, 'classic_checkout_notice' ) );
		add_action( 'admin_post_store_kit_classic_checkout', array( __CLASS__, 'switch_to_classic_checkout' ) );
		add_shortcode( 'store_kit_trust', array( __CLASS__, 'trust_shortcode' ) );

		if ( self::on( 'f_announcement' ) ) {
			add_action( 'wp_body_open', array( __CLASS__, 'announcement_bar' ), 5 );
		}
		if ( self::on( 'f_whatsapp_button' ) ) {
			add_action( 'wp_footer', array( __CLASS__, 'whatsapp_button' ) );
		}
		if ( self::on( 'f_trust_strip' ) ) {
			add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'product_trust_strip' ), 31 );
		}
		if ( self::on( 'f_sticky_atc' ) ) {
			add_action( 'wp_footer', array( __CLASS__, 'sticky_atc' ) );
		}
		if ( self::on( 'f_simple_checkout' ) ) {
			add_filter( 'woocommerce_default_address_fields', array( __CLASS__, 'address_fields' ), 20 );
			add_filter( 'woocommerce_billing_fields', array( __CLASS__, 'billing_fields' ), 9999 );
			add_filter( 'pre_option_woocommerce_checkout_phone_field', function () { return 'required'; } );
			// Newer WooCommerce treats phone as an address field and relabels it in the browser; set it there too.
			add_filter(
				'woocommerce_default_address_fields',
				function ( $fields ) {
					if ( isset( $fields['phone'] ) ) {
						$fields['phone']['label']       = 'Mobile number';
						$fields['phone']['placeholder'] = '03XX XXXXXXX';
						$fields['phone']['required']    = true;
						$fields['phone']['priority']    = 20;
					}
					return $fields;
				},
				9999
			);
			add_filter(
				'woocommerce_checkout_fields',
				function ( $fields ) {
					if ( isset( $fields['billing']['billing_phone'] ) ) {
						$fields['billing']['billing_phone'] = array_merge(
							$fields['billing']['billing_phone'],
							array(
								'label'       => 'Mobile number',
								'placeholder' => '03XX XXXXXXX',
								'required'    => true,
								'priority'    => 20,
								'class'       => array( 'form-row-wide' ),
							)
						);
						uasort(
							$fields['billing'],
							function ( $a, $b ) {
								return ( isset( $a['priority'] ) ? $a['priority'] : 999 ) - ( isset( $b['priority'] ) ? $b['priority'] : 999 );
							}
						);
					}
					return $fields;
				},
				9999
			);
			add_filter( 'woocommerce_available_payment_gateways', array( __CLASS__, 'cod_first' ), 20 );
		}
		if ( self::on( 'f_phone_validation' ) ) {
			add_filter( 'woocommerce_checkout_posted_data', array( __CLASS__, 'normalise_posted_phone' ) );
			add_action( 'woocommerce_after_checkout_validation', array( __CLASS__, 'validate_phone' ), 10, 2 );
		}

		if ( self::on( 'f_free_ship_only' ) ) {
			add_filter( 'woocommerce_package_rates', array( __CLASS__, 'free_shipping_only' ), 100 );
		}

		add_filter( 'woocommerce_thankyou_order_received_text', array( __CLASS__, 'thankyou_text' ), 20, 2 );
	}

	public static function admin_menu() {
		$parent = class_exists( 'WooCommerce' ) ? 'woocommerce' : 'options-general.php';
		add_submenu_page( $parent, 'Store Kit', 'Store Kit', 'manage_woocommerce', 'store-kit', array( __CLASS__, 'settings_page' ) );
	}

	public static function action_links( $links ) {
		$url = admin_url( class_exists( 'WooCommerce' ) ? 'admin.php?page=store-kit' : 'options-general.php?page=store-kit' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">Settings</a>' );
		return $links;
	}

	public static function register_settings() {
		register_setting( 'store_kit', self::OPT, array( 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
		add_filter( 'option_page_capability_store_kit', function () { return 'manage_woocommerce'; } );
	}

	public static function sanitize( $in ) {
		$in  = (array) $in;
		$d   = self::defaults();
		$out = array();

		$wa = preg_replace( '/\D+/', '', isset( $in['whatsapp'] ) ? $in['whatsapp'] : '' );
		if ( 0 === strpos( $wa, '0092' ) ) {
			$wa = substr( $wa, 2 );
		} elseif ( 0 === strpos( $wa, '0' ) ) {
			$wa = '92' . substr( $wa, 1 );
		}
		$out['whatsapp'] = $wa;

		foreach ( array( 'whatsapp_message', 'announcement', 'delivery_time', 'exchange_text' ) as $k ) {
			$out[ $k ] = sanitize_text_field( isset( $in[ $k ] ) ? $in[ $k ] : '' );
		}
		foreach ( array( 'brand_color', 'accent_color' ) as $k ) {
			$c         = sanitize_hex_color( isset( $in[ $k ] ) ? $in[ $k ] : '' );
			$out[ $k ] = $c ? $c : $d[ $k ];
		}
		foreach ( array_keys( self::features() ) as $k ) {
			$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		}
		return $out;
	}

	public static function settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$name = self::OPT;
		$text = array(
			'whatsapp'         => array( 'WhatsApp number', 'e.g. 0300 1234567. Used by the floating button and trust strip.' ),
			'whatsapp_message' => array( 'WhatsApp opening message', 'Pre-filled text when a customer taps the button.' ),
			'announcement'     => array( 'Announcement bar text', 'Use | to separate messages.' ),
			'delivery_time'    => array( 'Delivery time', 'Shown on every product page.' ),
			'exchange_text'    => array( 'Exchange policy (short)', 'Shown on every product page; links to your policy page in the footer.' ),
		);
		?>
		<div class="wrap">
			<h1>Store Kit</h1>
			<p>Site essentials from the store PRD. Leave a feature switched off if your theme already does the same thing.</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'store_kit' ); ?>
				<table class="form-table" role="presentation">
					<?php foreach ( $text as $k => $meta ) : ?>
						<tr>
							<th scope="row"><label for="sk-<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $meta[0] ); ?></label></th>
							<td>
								<input type="text" class="regular-text" id="sk-<?php echo esc_attr( $k ); ?>" name="<?php echo esc_attr( $name . '[' . $k . ']' ); ?>" value="<?php echo esc_attr( self::opt( $k ) ); ?>">
								<p class="description"><?php echo esc_html( $meta[1] ); ?></p>
							</td>
						</tr>
					<?php endforeach; ?>
					<tr>
						<th scope="row">Colours</th>
						<td>
							<label>Brand <input type="color" name="<?php echo esc_attr( $name . '[brand_color]' ); ?>" value="<?php echo esc_attr( self::opt( 'brand_color' ) ); ?>"></label>
							&nbsp;
							<label>Accent <input type="color" name="<?php echo esc_attr( $name . '[accent_color]' ); ?>" value="<?php echo esc_attr( self::opt( 'accent_color' ) ); ?>"></label>
							<p class="description">Use the same two colours you set in your theme.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Features</th>
						<td>
							<?php foreach ( self::features() as $k => $label ) : ?>
								<label style="display:block;margin-bottom:6px">
									<input type="checkbox" name="<?php echo esc_attr( $name . '[' . $k . ']' ); ?>" value="1" <?php checked( self::on( $k ) ); ?>>
									<?php echo esc_html( $label ); ?>
								</label>
							<?php endforeach; ?>
						</td>
					</tr>
				</table>
				<p>Put the trust strip anywhere (homepage, footer widget) with the shortcode <code>[store_kit_trust]</code>.</p>
				<?php submit_button( 'Save changes' ); ?>
			</form>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Front end
	 * ------------------------------------------------------------------ */

	public static function assets() {
		wp_enqueue_style( 'store-kit', STORE_KIT_URL . 'assets/store-kit.css', array(), STORE_KIT_VERSION );
		wp_add_inline_style(
			'store-kit',
			sprintf( ':root{--sk-brand:%s;--sk-accent:%s;}', esc_attr( self::opt( 'brand_color' ) ), esc_attr( self::opt( 'accent_color' ) ) )
		);

		if ( is_product() && ( self::on( 'f_swatches' ) || self::on( 'f_sticky_atc' ) ) ) {
			wp_enqueue_script( 'store-kit', STORE_KIT_URL . 'assets/store-kit.js', array( 'jquery' ), STORE_KIT_VERSION, true );
			wp_localize_script(
				'store-kit',
				'StoreKit',
				array(
					'swatches' => self::on( 'f_swatches' ),
					'sticky'   => self::on( 'f_sticky_atc' ),
				)
			);
		}
	}

	public static function body_class( $classes ) {
		if ( function_exists( 'is_product' ) && is_product() && self::on( 'f_sticky_atc' ) ) {
			$classes[] = 'sk-has-sticky-atc';
		}
		return $classes;
	}

	public static function wa_link( $message = '' ) {
		$number = self::opt( 'whatsapp' );
		if ( ! $number ) {
			return '';
		}
		$message = $message ? $message : self::opt( 'whatsapp_message' );
		return 'https://wa.me/' . rawurlencode( $number ) . ( $message ? '?text=' . rawurlencode( $message ) : '' );
	}

	public static function announcement_bar() {
		$text = trim( self::opt( 'announcement' ) );
		if ( '' === $text ) {
			return;
		}
		$parts = array_filter( array_map( 'trim', explode( '|', $text ) ) );
		$items = array();
		foreach ( $parts as $part ) {
			$items[] = '<span class="sk-announcement__item">' . self::announcement_icon( $part ) . esc_html( $part ) . '</span>';
		}
		echo '<div class="sk-announcement" role="region" aria-label="Store announcements"><p>';
		echo implode( '<span class="sk-announcement__sep" aria-hidden="true"></span>', $items ); // Items are built from escaped text and fixed SVG markup.
		echo '</p></div>';
	}

	/**
	 * Picks a small icon for an announcement message: cash for COD, a truck for delivery.
	 */
	private static function announcement_icon( $text ) {
		$t    = strtolower( $text );
		$open = '<svg class="sk-announcement__icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">';
		if ( false !== strpos( $t, 'cash' ) || false !== strpos( $t, 'cod' ) ) {
			return $open . '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9.5v5M18 9.5v5"/></svg>';
		}
		if ( false !== strpos( $t, 'deliver' ) || false !== strpos( $t, 'shipping' ) ) {
			return $open . '<path d="M2.5 6.5h11v9h-11zM13.5 9.5h4l3 3v3h-7"/><circle cx="6.5" cy="17" r="1.8"/><circle cx="17" cy="17" r="1.8"/></svg>';
		}
		return '';
	}

	/**
	 * Cart and checkout pages built with blocks cannot use the simplified checkout, phone check or
	 * WhatsApp thank-you text. Offer a one-click switch to the classic pages.
	 */
	private static function block_pages() {
		$out = array();
		foreach ( array( 'cart' => 'woocommerce/cart', 'checkout' => 'woocommerce/checkout' ) as $page => $block ) {
			$id = wc_get_page_id( $page );
			if ( $id > 0 ) {
				$post = get_post( $id );
				if ( $post && has_block( $block, $post ) ) {
					$out[ $page ] = $id;
				}
			}
		}
		return $out;
	}

	public static function classic_checkout_notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! self::block_pages() ) {
			return;
		}
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=store_kit_classic_checkout' ), 'store_kit_classic_checkout' );
		echo '<div class="notice notice-warning"><p><strong>Store Kit:</strong> your Cart and Checkout pages use the newer block layout, so the one-page COD checkout, Pakistani phone check and WhatsApp thank-you message cannot work yet.</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( $url ) . '">Switch to classic cart and checkout</a></p></div>';
	}

	public static function switch_to_classic_checkout() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'store-kit' ) );
		}
		check_admin_referer( 'store_kit_classic_checkout' );
		$codes = array(
			'cart'     => '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->',
			'checkout' => '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->',
		);
		foreach ( self::block_pages() as $page => $id ) {
			wp_update_post( array( 'ID' => $id, 'post_content' => $codes[ $page ] ) );
		}
		wp_safe_redirect( add_query_arg( 'store_kit_switched', '1', admin_url( 'admin.php?page=store-kit' ) ) );
		exit;
	}

	public static function whatsapp_button() {
		$message = '';
		if ( is_product() ) {
			$message = sprintf( 'Hi! I have a question about %s: %s', get_the_title(), get_permalink() );
		}
		$link = self::wa_link( $message );
		if ( ! $link ) {
			return;
		}
		printf(
			'<a class="sk-whatsapp" href="%s" target="_blank" rel="noopener" aria-label="Chat with us on WhatsApp">%s</a>',
			esc_url( $link ),
			self::icon( 'whatsapp' ) // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG.
		);
	}

	public static function trust_items() {
		$items = array(
			array( 'cod', 'Cash on Delivery', 'Pay when it reaches you' ),
			array( 'truck', self::opt( 'delivery_time' ), 'All over Pakistan' ),
			array( 'exchange', self::opt( 'exchange_text' ), 'Wrong size? We will swap it' ),
		);
		if ( self::opt( 'whatsapp' ) ) {
			$items[] = array( 'whatsapp', 'Questions? WhatsApp us', 'Quick replies', self::wa_link() );
		}
		return $items;
	}

	public static function render_trust( $context ) {
		$html = '<ul class="sk-trust sk-trust--' . esc_attr( $context ) . '">';
		foreach ( self::trust_items() as $item ) {
			if ( '' === trim( $item[1] ) ) {
				continue;
			}
			$inner = self::icon( $item[0] ) . '<span><strong>' . esc_html( $item[1] ) . '</strong><small>' . esc_html( $item[2] ) . '</small></span>';
			if ( ! empty( $item[3] ) ) {
				$inner = '<a href="' . esc_url( $item[3] ) . '" target="_blank" rel="noopener">' . $inner . '</a>';
			}
			$html .= '<li>' . $inner . '</li>';
		}
		return $html . '</ul>';
	}

	public static function product_trust_strip() {
		echo self::render_trust( 'product' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in render_trust.
	}

	public static function trust_shortcode() {
		return self::render_trust( 'block' );
	}

	public static function sticky_atc() {
		if ( ! is_product() ) {
			return;
		}
		$product = wc_get_product( get_the_ID() );
		if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			return;
		}
		?>
		<div class="sk-sticky-atc is-hidden" aria-hidden="true">
			<div class="sk-sticky-atc__info">
				<span class="sk-sticky-atc__name"><?php echo esc_html( $product->get_name() ); ?></span>
				<span class="sk-sticky-atc__price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
			</div>
			<button type="button" class="sk-sticky-atc__btn" tabindex="-1">Add to cart</button>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Checkout
	 * ------------------------------------------------------------------ */

	public static function address_fields( $fields ) {
		unset( $fields['last_name'], $fields['company'], $fields['address_2'], $fields['postcode'], $fields['state'] );

		if ( isset( $fields['first_name'] ) ) {
			$fields['first_name']['label']       = 'Full name';
			$fields['first_name']['class']       = array( 'form-row-wide' );
			$fields['first_name']['priority']    = 10;
			$fields['first_name']['autocomplete'] = 'name';
		}
		if ( isset( $fields['city'] ) ) {
			$fields['city']['label']       = 'City';
			$fields['city']['placeholder'] = 'e.g. Lahore';
			$fields['city']['priority']    = 30;
		}
		if ( isset( $fields['address_1'] ) ) {
			$fields['address_1']['label']       = 'Full address';
			$fields['address_1']['placeholder'] = 'House no., street, area';
			$fields['address_1']['priority']    = 40;
		}
		if ( isset( $fields['country'] ) ) {
			$fields['country']['priority'] = 90;
		}
		return $fields;
	}

	public static function billing_fields( $fields ) {
		if ( isset( $fields['billing_phone'] ) ) {
			$fields['billing_phone']['label']       = 'Mobile number';
			$fields['billing_phone']['placeholder'] = '03XX XXXXXXX';
			$fields['billing_phone']['required']    = true;
			$fields['billing_phone']['priority']    = 20;
			$fields['billing_phone']['class']       = array( 'form-row-wide' );
		}
		if ( isset( $fields['billing_email'] ) ) {
			$fields['billing_email']['label']    = 'Email for order updates';
			$fields['billing_email']['required'] = false;
			$fields['billing_email']['priority'] = 50;
		}
		return $fields;
	}

	/**
	 * Over the free-shipping amount, WooCommerce still lists the flat rate first and pre-selects it,
	 * so customers could pay for delivery they should get free. Keep only the free options.
	 */
	public static function free_shipping_only( $rates ) {
		$free = array();
		foreach ( $rates as $id => $rate ) {
			if ( in_array( $rate->get_method_id(), array( 'free_shipping', 'local_pickup', 'pickup_location' ), true ) ) {
				$free[ $id ] = $rate;
			}
		}
		foreach ( $free as $rate ) {
			if ( 'free_shipping' === $rate->get_method_id() ) {
				return $free;
			}
		}
		return $rates;
	}

	public static function cod_first( $gateways ) {
		if ( is_admin() || ! isset( $gateways['cod'] ) ) {
			return $gateways;
		}
		$cod = array( 'cod' => $gateways['cod'] );
		unset( $gateways['cod'] );
		return $cod + $gateways;
	}

	/**
	 * Accepts 03001234567, 0300-1234567, +92 300 1234567, 923001234567, 00923001234567.
	 * Returns the number as 03001234567, or false if it is not a Pakistani mobile number.
	 */
	public static function normalise_pk_phone( $raw ) {
		$d = preg_replace( '/\D+/', '', (string) $raw );
		if ( 0 === strpos( $d, '0092' ) ) {
			$d = substr( $d, 4 );
		} elseif ( 0 === strpos( $d, '92' ) && 12 === strlen( $d ) ) {
			$d = substr( $d, 2 );
		} elseif ( 0 === strpos( $d, '0' ) ) {
			$d = substr( $d, 1 );
		}
		return preg_match( '/^3\d{9}$/', $d ) ? '0' . $d : false;
	}

	public static function normalise_posted_phone( $data ) {
		if ( ! empty( $data['billing_phone'] ) ) {
			$clean = self::normalise_pk_phone( $data['billing_phone'] );
			if ( $clean ) {
				$data['billing_phone'] = $clean;
			}
		}
		return $data;
	}

	public static function validate_phone( $data, $errors ) {
		if ( empty( $data['billing_phone'] ) ) {
			return; // WooCommerce already reports the required field.
		}
		if ( ! self::normalise_pk_phone( $data['billing_phone'] ) ) {
			$errors->add( 'validation', '<strong>Mobile number</strong> must be a Pakistani mobile number, like 0300 1234567.' );
		}
	}

	public static function thankyou_text( $text, $order ) {
		if ( ! $order instanceof WC_Order ) {
			return $text;
		}
		return sprintf(
			'Thank you! Your order number is <strong>#%s</strong>. We will confirm on WhatsApp shortly.',
			esc_html( $order->get_order_number() )
		);
	}

	/* ------------------------------------------------------------------ *
	 * Icons
	 * ------------------------------------------------------------------ */

	public static function icon( $name ) {
		$paths = array(
			'cod'      => '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9.5v5M18 9.5v5"/>',
			'truck'    => '<path d="M2.5 6.5h11v9h-11zM13.5 9.5h4l3 3v3h-7"/><circle cx="6.5" cy="17" r="1.8"/><circle cx="17" cy="17" r="1.8"/>',
			'exchange' => '<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
			'whatsapp' => '<path d="M12 3a9 9 0 0 0-7.8 13.5L3 21l4.6-1.2A9 9 0 1 0 12 3z"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.5-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2z"/>',
		);
		if ( ! isset( $paths[ $name ] ) ) {
			return '';
		}
		return '<svg class="sk-icon" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
	}
}

add_action( 'plugins_loaded', array( 'Store_Kit', 'init' ) );
