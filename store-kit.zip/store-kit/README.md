# Store Kit – Site Essentials (v1.2.1)

A small site-specific plugin that covers the parts of the PRD that need code. Everything else in the PRD is done with WooCommerce settings and your theme (see the checklist below).

## Install (PRD step 6)

1. WordPress admin → Plugins → Add New → Upload Plugin → choose `store-kit.zip` → Install → Activate.
2. WooCommerce → Store Kit: enter your WhatsApp number, announcement text, delivery time, exchange line and your two brand colours. Save.
3. **Switch the checkout to the classic checkout** (required for the simplified fields and phone validation): Pages → Checkout → click the Checkout block → in the right sidebar choose "Switch to classic checkout". Do the same on the Cart page. The page should then contain `[woocommerce_checkout]` / `[woocommerce_cart]`.

This plugin replaces the separate WhatsApp button plugin in the PRD, so your plugin list stays short.

## What it does

| PRD requirement | Where |
| --- | --- |
| Announcement bar for COD and free shipping | Top of every page, with a cash icon for COD and a truck icon for delivery messages |
| WhatsApp button | Bottom right on every page; on product pages the message includes the product name |
| Trust signals: COD, delivery time, exchange, WhatsApp | Under "Add to cart"; anywhere else with `[store_kit_trust]` |
| Size and colour buttons instead of dropdowns | Product pages; out-of-stock sizes are shown crossed out and can't be picked |
| Sticky "Add to cart" on mobile | Appears when the real button scrolls off screen |
| One-page checkout: name, phone, city, address, optional email | Checkout (company, 2nd address line, postcode, province and last name removed) |
| Free delivery over the threshold | Paid delivery options are hidden once free shipping applies |
| COD selected by default | COD always listed first |
| Pakistani phone validation | Accepts 0300 1234567, +92 300 1234567 etc.; saved as 03001234567 |
| Thank you: order number + "We will confirm on WhatsApp" | Order received page |
| 16 px form text, 44 px buttons, 2-column shop grid on mobile, 4:5 photos | Stylesheet |

Every feature has an on/off switch in WooCommerce → Store Kit in case your theme already does it.

## Settings to set by hand (from the PRD)

**Settings → General:** Timezone = Karachi.
**Settings → Permalinks:** Post name.
**Settings → Reading:** Homepage = your Home page.

**WooCommerce → Settings → General**
- Selling location: Sell to specific countries → Pakistan
- Shipping location: Ship to all countries you sell to
- Currency: Pakistani rupee (Rs), 0 decimals

**WooCommerce → Settings → Products**
- Weight unit: kg
- Inventory: Enable stock management; Low stock threshold = 3; Out of stock threshold = 0
- Enable product reviews; Show "verified owner" label

**WooCommerce → Settings → Shipping**
- Shipping options: Force shipping to the customer billing address
- Add zone "Pakistan" (region: Pakistan) → Flat rate (e.g. 250) and Free shipping (requires a minimum order amount, e.g. 5000)
- Make the announcement bar text match your free-shipping amount

**WooCommerce → Settings → Payments**
- Enable Cash on Delivery (title "Cash on Delivery", enable for shipping methods: leave empty = all)
- Enable Direct bank transfer and add your account details

**WooCommerce → Settings → Accounts & Privacy**
- Allow customers to place orders without an account: on
- Allow customers to create an account during checkout: on

**WooCommerce → Settings → Emails**
- New order recipient: your business Gmail
- Check "Processing order" is enabled for customers

**Appearance → Customize → WooCommerce → Product Images**
- Thumbnail cropping: Custom 4:5 (upload photos at 1200 × 1500, under 200 KB)

## Launch check for this plugin

- [ ] Place a COD order on a phone with number `0300 1234567` → accepted
- [ ] Try `12345` → error "Mobile number must be a Pakistani mobile number"
- [ ] Thank you page shows the order number and the WhatsApp line
- [ ] Out-of-stock size is crossed out on the product page
- [ ] WhatsApp button opens a chat with your number
