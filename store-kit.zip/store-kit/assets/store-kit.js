/* Store Kit: size/colour buttons and sticky mobile "Add to cart". */
(function ($) {
	'use strict';

	var cfg = window.StoreKit || {};

	/* ---------- Size and colour buttons ---------- */

	function buildSwatches($form) {
		$form.find('table.variations select').each(function () {
			var $select = $(this);
			if ($select.data('skDone')) { return; }
			$select.data('skDone', true);

			var label = $.trim($select.closest('tr').find('th label, .label label').first().text());
			var $wrap = $('<div class="sk-swatches" role="group"></div>').attr('aria-label', label || 'Options');

			$select.find('option').each(function () {
				if (!this.value) { return; }
				$('<button type="button" class="sk-swatch" aria-pressed="false"></button>')
					.text($(this).text())
					.attr('data-value', this.value)
					.appendTo($wrap);
			});

			$select.addClass('sk-select-hidden').attr({ 'aria-hidden': 'true', tabindex: '-1' }).after($wrap);

			$wrap.on('click', '.sk-swatch', function () {
				var $btn = $(this);
				if ($btn.hasClass('is-disabled')) { return; }
				var val = $btn.attr('data-value');
				$select.val($select.val() === val ? '' : val).trigger('change');
			});
		});
		sync($form);
	}

	// Mirror the hidden select: selected value, and which options WooCommerce still allows.
	function sync($form) {
		$form.find('table.variations select').each(function () {
			var $select = $(this);
			var $wrap = $select.next('.sk-swatches');
			if (!$wrap.length) { return; }

			var current = $select.val();
			var allowed = {};
			$select.find('option').each(function () {
				if (this.value && !this.disabled) { allowed[this.value] = true; }
			});

			$wrap.find('.sk-swatch').each(function () {
				var $btn = $(this);
				var val = $btn.attr('data-value');
				var selected = val === current;
				$btn.toggleClass('is-selected', selected).attr('aria-pressed', selected ? 'true' : 'false');
				$btn.toggleClass('is-disabled', !allowed[val]).attr('aria-disabled', allowed[val] ? 'false' : 'true');
			});
		});
	}

	function initForm($form) {
		if (!cfg.swatches || $form.data('skInit')) { return; }
		$form.data('skInit', true);
		buildSwatches($form);
		$form.on('woocommerce_update_variation_values reset_data change', function () { sync($form); });
	}

	$(document).on('wc_variation_form', '.variations_form', function () { initForm($(this)); });

	/* ---------- Sticky "Add to cart" ---------- */

	function initSticky() {
		if (!cfg.sticky) { return; }
		var $bar = $('.sk-sticky-atc');
		var $main = $('form.cart .single_add_to_cart_button').first();
		if (!$bar.length || !$main.length) { $bar.remove(); return; }

		var $form = $main.closest('form');
		var $price = $bar.find('.sk-sticky-atc__price');
		var basePrice = $price.html();

		$bar.on('click', '.sk-sticky-atc__btn', function (e) {
			e.preventDefault();
			var needsChoice = $main.is(':disabled') || $main.hasClass('disabled') || $main.hasClass('wc-variation-selection-needed');
			if (needsChoice) {
				$('html, body').animate({ scrollTop: $form.offset().top - 120 }, 250);
				$form.find('.sk-swatch:not(.is-disabled), select').first().trigger('focus');
			} else {
				$main.trigger('click');
			}
		});

		// Show the chosen variation's price in the bar.
		$form.on('found_variation', function (e, variation) {
			if (variation && variation.price_html) { $price.html(variation.price_html); }
		}).on('reset_data', function () { $price.html(basePrice); });

		// Hide the bar while the real button is on screen.
		if ('IntersectionObserver' in window) {
			new IntersectionObserver(function (entries) {
				var visible = entries[0].isIntersecting;
				$bar.toggleClass('is-hidden', visible).attr('aria-hidden', visible ? 'true' : 'false');
				$bar.find('.sk-sticky-atc__btn').attr('tabindex', visible ? '-1' : '0');
			}).observe($main[0]);
		} else {
			$bar.removeClass('is-hidden').attr('aria-hidden', 'false');
		}
	}

	$(function () {
		$('.variations_form').each(function () { initForm($(this)); });
		initSticky();
	});
})(jQuery);
