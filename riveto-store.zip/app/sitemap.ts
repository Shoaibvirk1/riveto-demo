import type { MetadataRoute } from "next";
import { products, categories, catalogDate, mainImage } from "@/lib/products";
import { infoPages } from "@/lib/pages";
import { absUrl } from "@/lib/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date(catalogDate);
  return [
    { url: absUrl("/"), lastModified, changeFrequency: "daily", priority: 1 },
    { url: absUrl("/shop"), lastModified, changeFrequency: "daily", priority: 0.9 },
    ...categories.map((c) => ({ url: absUrl(`/category/${c.slug}`), lastModified, changeFrequency: "weekly" as const, priority: 0.8 })),
    ...products.map((p) => ({
      url: absUrl(`/product/${p.slug}`), lastModified, changeFrequency: "weekly" as const, priority: 0.7,
      images: (p.images.length ? p.images : [mainImage(p)]).map((i) => absUrl(i)),
    })),
    ...infoPages.map((p) => ({ url: absUrl(`/${p.slug}`), lastModified, changeFrequency: "monthly" as const, priority: 0.4 })),
  ];
}
