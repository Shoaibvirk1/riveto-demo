import { Suspense } from "react";
import { products, toList } from "@/lib/products";
import { pageMeta, graph, breadcrumbLd, itemListLd } from "@/lib/seo";
import ShopBrowser from "@/components/ShopBrowser";
import { ProductGrid } from "@/components/ProductCard";
import Breadcrumbs from "@/components/Breadcrumbs";
import JsonLd from "@/components/JsonLd";

export const metadata = pageMeta({
  title: "Shop jeans, cargo pants and chinos",
  description: "Shop every Riveto style: men's and women's jeans, cargo pants and chinos in real waist sizes. Cash on Delivery across Pakistan.",
  path: "/shop",
});

const crumbs = [{ name: "Home", path: "/" }, { name: "Shop", path: "/shop" }];

export default function ShopPage() {
  const list = products.map(toList);
  return (
    <main id="main" className="wrap page" tabIndex={-1}>
      <JsonLd data={graph(breadcrumbLd(crumbs), itemListLd(products, "All styles"))} />
      <Breadcrumbs items={crumbs} />
      <Suspense fallback={<><header className="page-head"><h1>Shop</h1></header><ProductGrid list={list} priorityFirst={4} headingLevel={2} /></>}>
        <ShopBrowser all={list} title="Shop" />
      </Suspense>
    </main>
  );
}
