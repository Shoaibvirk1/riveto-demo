import { NextResponse } from "next/server";
import { products } from "@/lib/products";
import { normalisePkPhone } from "@/lib/phone";
import { shippingFor } from "@/lib/cart-math";
import { site, whatsappLink } from "@/lib/site";
import { rs } from "@/lib/format";

/*
  Places a Cash on Delivery order.

  Prices, stock and delivery are always worked out again here from the product data, so nobody can
  change a price in their browser. Every order is:
    1. printed to the server log (Vercel → your project → Logs), so no order is ever lost, and
    2. sent to ORDER_WEBHOOK_URL if you set one (a Google Sheet, Zapier, Make, Slack, Discord...).
  The customer then gets a button to send the order to your WhatsApp.
*/

export const dynamic = "force-dynamic";

const VARIANTS = new Map(products.flatMap((p) => p.variants.map((v) => [v.sku, { p, v }] as const)));
const clip = (s: unknown, n: number) => String(s ?? "").replace(/\s+/g, " ").trim().slice(0, n);

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  // Honeypot: real customers never fill this hidden field.
  if (clip(body.website, 50)) return NextResponse.json({ error: "Invalid request." }, { status: 400 });

  const name = clip(body.name, 80);
  const phone = normalisePkPhone(clip(body.phone, 30));
  const city = clip(body.city, 60);
  const address = clip(body.address, 300);
  const email = clip(body.email, 120);
  const note = clip(body.note, 300);

  const errors: Record<string, string> = {};
  if (name.length < 2) errors.name = "Enter your full name.";
  if (!phone) errors.phone = "Enter a Pakistani mobile number, like 0300 1234567.";
  if (city.length < 2) errors.city = "Enter your city.";
  if (address.length < 8) errors.address = "Enter your full address: house number, street and area.";
  if (email && !/^\S+@\S+\.\S+$/.test(email)) errors.email = "Enter a valid email, or leave it empty.";

  const raw = Array.isArray(body.items) ? body.items.slice(0, 30) : [];
  const lines: { sku: string; name: string; colour: string; size: string; qty: number; price: number }[] = [];
  for (const it of raw as { sku?: unknown; qty?: unknown }[]) {
    const hit = VARIANTS.get(String(it?.sku));
    const qty = Math.floor(Number(it?.qty));
    if (!hit || !(qty > 0)) continue;
    if (hit.v.stock < qty) {
      errors.form = hit.v.stock > 0
        ? `Only ${hit.v.stock} left of ${hit.p.name} (${hit.v.colour}, waist ${hit.v.size}). Lower the quantity in your cart.`
        : `${hit.p.name} (${hit.v.colour}, waist ${hit.v.size}) just sold out. Remove it from your cart.`;
      continue;
    }
    lines.push({ sku: hit.v.sku, name: hit.p.name, colour: hit.v.colour, size: hit.v.size, qty, price: hit.v.price });
  }
  if (!lines.length && !errors.form) errors.form = "Your cart is empty.";
  if (Object.keys(errors).length) return NextResponse.json({ errors }, { status: 422 });

  const subtotal = lines.reduce((n, l) => n + l.qty * l.price, 0);
  const shipping = shippingFor(subtotal);
  const total = subtotal + shipping;

  // RV-<yymmdd>-<4 random>, readable over the phone.
  const pk = new Date(Date.now() + 5 * 3600 * 1000);
  const id = `RV-${pk.toISOString().slice(2, 10).replace(/-/g, "")}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;

  const order = {
    id, createdAt: new Date().toISOString(), payment: "Cash on Delivery",
    customer: { name, phone, city, address, email, note },
    lines, subtotal, shipping, total,
  };

  console.log("NEW ORDER", JSON.stringify(order));

  const hook = process.env.ORDER_WEBHOOK_URL;
  if (hook) {
    try {
      await fetch(hook, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(order), signal: AbortSignal.timeout(6000) });
    } catch (e) {
      console.error("ORDER WEBHOOK FAILED", id, e);
    }
  }

  const message = [
    `New order ${id}`,
    ...lines.map((l) => `• ${l.name}, ${l.colour}, waist ${l.size} × ${l.qty} = ${rs(l.price * l.qty)}`),
    `Delivery: ${shipping ? rs(shipping) : "Free"}`,
    `Total (COD): ${rs(total)}`,
    "",
    `${name}, ${phone}`,
    `${address}, ${city}`,
    ...(note ? [`Note: ${note}`] : []),
  ].join("\n");

  return NextResponse.json({
    order: { id, total, shipping, name, whatsappUrl: whatsappLink(message) },
  });
}

export function GET() {
  return NextResponse.json({ ok: true, store: site.name });
}
