import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { infoPages, getInfoPage } from "@/lib/pages";
import { pageMeta, graph, breadcrumbLd, faqLd } from "@/lib/seo";
import { absUrl, whatsappLink, whatsappDisplay } from "@/lib/site";
import Breadcrumbs from "@/components/Breadcrumbs";
import JsonLd from "@/components/JsonLd";

type Params = { params: Promise<{ page: string }> };

export const dynamicParams = false;
export const generateStaticParams = () => infoPages.map((p) => ({ page: p.slug }));

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const p = getInfoPage((await params).page);
  return p ? pageMeta({ title: p.title, description: p.description, path: `/${p.slug}`, type: "article" }) : {};
}

export default async function InfoPage({ params }: Params) {
  const p = getInfoPage((await params).page);
  if (!p) notFound();
  const crumbs = [{ name: "Home", path: "/" }, { name: p.title, path: `/${p.slug}` }];
  const wa = whatsappDisplay();
  return (
    <main id="main" className="wrap page narrow prose" tabIndex={-1}>
      <JsonLd data={graph(
        { "@type": "WebPage", "@id": absUrl(`/${p.slug}`), url: absUrl(`/${p.slug}`), name: p.title, description: p.description },
        breadcrumbLd(crumbs),
        ...(p.faqs ? [faqLd(p.faqs)] : []),
      )} />
      <Breadcrumbs items={crumbs} />
      <h1>{p.title}</h1>
      {p.body.map((b) => (b.startsWith("## ") ? <h2 key={b}>{b.slice(3)}</h2> : <p key={b}>{b}</p>))}
      {p.faqs && (
        <div className="faq">
          {p.faqs.map((f, i) => (
            <details key={f.q} open={i === 0}>
              <summary>{f.q}<span className="chev" aria-hidden="true" /></summary>
              <p>{f.a}</p>
            </details>
          ))}
        </div>
      )}
      {wa && <p className="contact-line">Questions? WhatsApp us on <a href={whatsappLink()} target="_blank" rel="noopener">{wa}</a>.</p>}
    </main>
  );
}
