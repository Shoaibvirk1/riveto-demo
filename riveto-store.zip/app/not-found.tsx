import Link from "next/link";

export default function NotFound() {
  return (
    <main id="main" className="wrap page narrow" tabIndex={-1}>
      <h1>This page is not here</h1>
      <p>The link may be old or mistyped. Search for what you need or go back to the shop.</p>
      <p><Link className="btn" href="/shop">Go to the shop</Link></p>
    </main>
  );
}
