import type { MetadataRoute } from "next";
import { absUrl } from "@/lib/site";

export default function robots(): MetadataRoute.Robots {
  // Preview deployments (and any non-production build) are kept out of search results.
  const isProd = !process.env.VERCEL_ENV || process.env.VERCEL_ENV === "production";
  return {
    rules: isProd
      ? [{ userAgent: "*", allow: "/", disallow: ["/cart", "/checkout", "/order", "/api/", "/search"] }]
      : [{ userAgent: "*", disallow: "/" }],
    sitemap: absUrl("/sitemap.xml"),
    host: absUrl("/"),
  };
}
