import Link from "next/link";
import { preload } from "react-dom";
import Image from "next/image";
import { site } from "@/lib/site";
import { categories, productsIn, featured, bestSellers, newArrivals, mainImage, isNew } from "@/lib/products";
import { slides, SLIDE_SECONDS } from "@/lib/home";
import { pageMeta, graph, organizationLd, websiteLd, itemListLd } from "@/lib/seo";
import HeroSlider from "@/components/HeroSlider";
import { Price, ProductGrid } from "@/components/ProductCard";
import ProductImage from "@/components/ProductImage";
import TrustBand from "@/components/TrustBand";
import JsonLd from "@/components/JsonLd";
import Icon from "@/components/Icon";

export const metadata = pageMeta({
  description: site.description,
  path: "/",
});

const SCENES = ["sc-street", "sc-shutter", "sc-studio", "sc-gallery", "sc-sky", "sc-white"];
const CAT_ART: Record<string, string> = { men: "men", women: "women", "cargo-pants": "cargo", "chinos-trousers": "chinos" };

export default function Home() {
  // The first banner's denim texture is the largest thing on screen: fetch it straight away.
  preload("/img/denim.webp", { as: "image", fetchPriority: "high" });
  const trending = featured(6);
  const best = bestSellers(4);
  const fresh = newArrivals(4);

  return (
    <main id="main" tabIndex={-1}>
      <JsonLd data={graph(organizationLd(), websiteLd(), itemListLd(trending, "Trending this week"))} />
      <HeroSlider slides={slides} seconds={SLIDE_SECONDS} />

      <section className="wrap sec" aria-labelledby="trending-h">
        <div className="sec-h"><h2 id="trending-h">Trending this week</h2><Link href="/shop">See all styles</Link></div>
        <div className="bento">
          {trending.map((p, n) => (
            <Link key={p.slug} href={`/product/${p.slug}`} className={`m-item ${SCENES[n % 6]}`}>
              <span className="m-pic"><ProductImage src={mainImage(p)} alt={p.name} sizes="(max-width: 767px) 50vw, 33vw" /></span>
              {p.onSale ? <span className="badge sale">Sale</span> : isNew(p) ? <span className="badge">New</span> : null}
              <span className="m-cap"><b>{p.name}</b><Price p={p} /></span>
              <span className="m-go" aria-hidden="true"><Icon name="arrow" size={18} /></span>
            </Link>
          ))}
        </div>
      </section>

      <section className="wrap sec" aria-labelledby="cats-h">
        <div className="sec-h"><h2 id="cats-h">Shop by category</h2></div>
        <div className="tiles">
          {categories.map((c) => {
            const art = CAT_ART[c.slug] || "men";
            const count = productsIn(c.slug).length;
            return (
              <Link key={c.slug} href={`/category/${c.slug}`} className="tile">
                <span className="tile-pic" style={{ backgroundImage: `url(/img/scene-${art}.webp)` }}>
                  <Image src={`/img/cat-${art}.svg`} alt="" width={216} height={468} unoptimized className="art" />
                </span>
                <b>{c.name}</b>
                <small>{count} {count === 1 ? "style" : "styles"}</small>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="slogan" aria-label="Our promise">
        <div className="wrap slogan-in">
          <p className="slogan-big">{site.slogan}</p>
          <p className="slogan-sub">{site.sloganText}</p>
          <Link className="btn btn-dark" href="/shop">Explore the collection</Link>
        </div>
      </section>

      <section className="wrap sec" aria-labelledby="best-h">
        <div className="sec-h"><h2 id="best-h">Best-sellers</h2><Link href="/shop?sort=popular">View all</Link></div>
        <ProductGrid list={best} />
      </section>

      <TrustBand />

      <section className="wrap sec" aria-labelledby="new-h">
        <div className="sec-h"><h2 id="new-h">New arrivals</h2><Link href="/shop?sort=new">View all</Link></div>
        <ProductGrid list={fresh} />
      </section>
    </main>
  );
}
