import { Suspense } from "react";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { categories, getCategory, productsIn, toList, mainImage } from "@/lib/products";
import { pageMeta, graph, breadcrumbLd, itemListLd } from "@/lib/seo";
import { absUrl } from "@/lib/site";
import ShopBrowser from "@/components/ShopBrowser";
import { ProductGrid } from "@/components/ProductCard";
import Breadcrumbs from "@/components/Breadcrumbs";
import JsonLd from "@/components/JsonLd";

type Params = { params: Promise<{ slug: string }> };

export const dynamicParams = false;
export const generateStaticParams = () => categories.map((c) => ({ slug: c.slug }));

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const c = getCategory((await params).slug);
  if (!c) return {};
  const first = productsIn(c.slug)[0];
  return pageMeta({ title: c.title, description: c.intro, path: `/category/${c.slug}`, image: first ? mainImage(first) : undefined });
}

export default async function CategoryPage({ params }: Params) {
  const c = getCategory((await params).slug);
  if (!c) notFound();
  const items = productsIn(c.slug);
  const list = items.map(toList);
  const crumbs = [{ name: "Home", path: "/" }, { name: "Shop", path: "/shop" }, { name: c.name, path: `/category/${c.slug}` }];
  return (
    <main id="main" className="wrap page" tabIndex={-1}>
      <JsonLd
        data={graph(
          { "@type": "CollectionPage", "@id": absUrl(`/category/${c.slug}`), url: absUrl(`/category/${c.slug}`), name: c.title, description: c.intro },
          breadcrumbLd(crumbs),
          itemListLd(items, c.title),
        )}
      />
      <Breadcrumbs items={crumbs} />
      <Suspense fallback={<><header className="page-head"><h1>{c.title}</h1><p className="lede">{c.intro}</p></header><ProductGrid list={list} priorityFirst={4} headingLevel={2} /></>}>
        <ShopBrowser all={list} title={c.title} intro={c.intro} />
      </Suspense>
    </main>
  );
}
