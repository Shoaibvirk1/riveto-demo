import { Suspense } from "react";
import { products, toList, categories } from "@/lib/products";
import { pageMeta } from "@/lib/seo";
import ShopBrowser from "@/components/ShopBrowser";

// Search results are thin, changing pages: keep them out of Google, but let it follow the links.
export const metadata = pageMeta({ title: "Search", description: "Search Riveto jeans, cargo pants and chinos.", path: "/search", noindex: true });

export default function SearchPage() {
  const list = products.map((p) => ({ ...toList(p), tags: [...p.tags, categories.find((c) => c.slug === p.category)?.name.toLowerCase() || "", p.short.toLowerCase()] }));
  return (
    <main id="main" className="wrap page" tabIndex={-1}>
      <Suspense fallback={<header className="page-head"><h1>Search</h1></header>}>
        <ShopBrowser all={list} title="Search" showSearchHint />
      </Suspense>
    </main>
  );
}
