import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { products, getProduct, getCategory, related, mainImage, toList } from "@/lib/products";
import { pageMeta, graph, breadcrumbLd, productLd } from "@/lib/seo";
import { site, whatsappLink } from "@/lib/site";
import { rs } from "@/lib/format";
import ProductView from "@/components/ProductView";
import { ProductGrid } from "@/components/ProductCard";
import Breadcrumbs from "@/components/Breadcrumbs";
import JsonLd from "@/components/JsonLd";

type Params = { params: Promise<{ slug: string }> };

export const dynamicParams = false;
export const generateStaticParams = () => products.map((p) => ({ slug: p.slug }));

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const p = getProduct((await params).slug);
  if (!p) return {};
  const c = getCategory(p.category);
  const desc = `${p.short} ${rs(p.minPrice)}${p.onSale ? ` (was ${rs(p.regularPrice)})` : ""}. Waist ${p.sizes[0]}-${p.sizes[p.sizes.length - 1]} in ${p.colours.join(", ")}. Cash on Delivery across Pakistan.`;
  return pageMeta({ title: `${p.name}${c ? ` | ${c.title}` : ""}`, description: desc, path: `/product/${p.slug}`, image: mainImage(p) });
}

export default async function ProductPage({ params }: Params) {
  const p = getProduct((await params).slug);
  if (!p) notFound();
  const c = getCategory(p.category);
  const crumbs = [
    { name: "Home", path: "/" },
    ...(c ? [{ name: c.name, path: `/category/${c.slug}` }] : []),
    { name: p.name, path: `/product/${p.slug}` },
  ];
  const [lead, ...details] = p.description.split(/\n\s*\n/);
  return (
    <main id="main" className="wrap page" tabIndex={-1}>
      <JsonLd data={graph(productLd(p, c), breadcrumbLd(crumbs))} />
      <Breadcrumbs items={crumbs} />
      <ProductView
        p={toList(p)}
        categoryName={c?.title || ""}
        whatsapp={whatsappLink()}
        trust={{ delivery: site.deliveryTime, exchange: site.exchangeText }}
      />
      <section className="pdp-more" aria-label="Product details">
        <details open>
          <summary>Description<span className="chev" aria-hidden="true" /></summary>
          <div className="acc-body">
            <p>{lead}</p>
            {details.map((d) => (
              <ul key={d} className="specs">{d.split("\n").map((line) => {
                const [k, ...v] = line.split(":");
                return v.length ? <li key={line}><b>{k}:</b>{v.join(":")}</li> : <li key={line}>{line}</li>;
              })}</ul>
            ))}
          </div>
        </details>
        <details>
          <summary>Delivery and exchange<span className="chev" aria-hidden="true" /></summary>
          <div className="acc-body">
            <p>{site.deliveryTime}. Delivery is {rs(site.shipping.flat)}, free on orders over {rs(site.shipping.freeOver)}. Pay in cash when your parcel arrives.</p>
            <p>Wrong size? Message us within 7 days and we will swap it. Items must be unworn with tags.</p>
          </div>
        </details>
      </section>
      <section className="sec" aria-labelledby="rel-h">
        <div className="sec-h"><h2 id="rel-h">You may also like</h2></div>
        <ProductGrid list={related(p)} />
      </section>
    </main>
  );
}
