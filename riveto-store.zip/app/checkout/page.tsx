import { pageMeta } from "@/lib/seo";
import CheckoutForm from "@/components/CheckoutForm";

export const metadata = pageMeta({ title: "Checkout", description: "Place your Riveto order with Cash on Delivery.", path: "/checkout", noindex: true });

export default function CheckoutPage() {
  return (
    <main id="main" className="wrap page" tabIndex={-1}>
      <header className="page-head"><h1>Checkout</h1></header>
      <CheckoutForm />
    </main>
  );
}
