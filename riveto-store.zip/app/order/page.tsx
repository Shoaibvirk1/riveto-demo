import { pageMeta } from "@/lib/seo";
import OrderDone from "@/components/OrderDone";

export const metadata = pageMeta({ title: "Order placed", description: "Your Riveto order has been placed.", path: "/order", noindex: true });

export default function OrderPage() {
  return (
    <main id="main" className="wrap page narrow" tabIndex={-1}>
      <OrderDone />
    </main>
  );
}
