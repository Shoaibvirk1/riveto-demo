import { pageMeta } from "@/lib/seo";
import CartView from "@/components/CartView";

export const metadata = pageMeta({ title: "Your cart", description: "Your Riveto shopping cart.", path: "/cart", noindex: true });

export default function CartPage() {
  return (
    <main id="main" className="wrap page" tabIndex={-1}>
      <header className="page-head"><h1>Your cart</h1></header>
      <CartView />
    </main>
  );
}
