import { site, whatsappDisplay, whatsappLink } from "@/lib/site";
import Icon from "./Icon";

export default function TrustBand() {
  const wa = whatsappDisplay();
  return (
    <section className="trustband" aria-label="Shopping with us">
      <ul className="wrap trust">
        <li><Icon name="cash" /><span><b>Cash on Delivery</b><small>Pay when your parcel arrives</small></span></li>
        <li><Icon name="truck" /><span><b>{site.deliveryTime}</b><small>Anywhere in Pakistan</small></span></li>
        <li><Icon name="swap" /><span><b>{site.exchangeText}</b><small>Easy, no questions</small></span></li>
        {wa && <li><Icon name="chat" /><span><b>WhatsApp us</b><small><a href={whatsappLink()} target="_blank" rel="noopener">{wa}</a></small></span></li>}
      </ul>
    </section>
  );
}
