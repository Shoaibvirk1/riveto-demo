import Link from "next/link";
import type { ListProduct as Product } from "@/lib/product-utils";
import { mainImage, isNew } from "@/lib/product-utils";
import { rs } from "@/lib/format";
import ProductImage from "./ProductImage";
import QuickAdd from "./QuickAdd";

const TONE: Record<string, string> = { men: "tone-blue", women: "tone-rose", "cargo-pants": "tone-sage", "chinos-trousers": "tone-sand" };

export function Price({ p }: { p: Pick<Product, "minPrice" | "maxPrice" | "regularPrice" | "onSale"> }) {
  const range = p.minPrice !== p.maxPrice;
  return (
    <span className="price">
      {p.onSale && <del aria-label={`Was ${rs(p.regularPrice)}`}>{rs(p.regularPrice)}</del>}
      <ins aria-label={p.onSale ? `Now ${rs(p.minPrice)}` : undefined}>{range ? `From ${rs(p.minPrice)}` : rs(p.minPrice)}</ins>
    </span>
  );
}

export default function ProductCard({ p, priority = false, headingLevel = 3 }: { p: Product; priority?: boolean; headingLevel?: 2 | 3 }) {
  const colour = p.colours.find((c) => p.variants.some((v) => v.colour === c && v.stock > 0)) || p.colours[0] || "";
  const options = p.variants.filter((v) => v.colour === colour && v.stock > 0).map((v) => ({ sku: v.sku, size: v.size }));
  const H = `h${headingLevel}` as "h2" | "h3";
  return (
    <article className="card">
      <Link href={`/product/${p.slug}`} className="card-link">
        <span className={`card-pic ${TONE[p.category] || "tone-blue"}`}>
          <ProductImage src={mainImage(p)} alt={p.name} sizes="(max-width: 767px) 50vw, 25vw" priority={priority} />
          {p.onSale ? <span className="badge sale">Sale</span> : isNew(p) ? <span className="badge">New</span> : null}
          {!p.inStock && <span className="badge sold">Sold out</span>}
        </span>
        <span className="card-body">
          <H className="card-title">{p.name}</H>
          <Price p={p} />
        </span>
      </Link>
      {p.inStock && <QuickAdd name={p.name} colour={colour} options={options} />}
    </article>
  );
}

export function ProductGrid({ list, priorityFirst = 0, headingLevel = 3 }: { list: Product[]; priorityFirst?: number; headingLevel?: 2 | 3 }) {
  return (
    <ul className="grid">
      {list.map((p, i) => <li key={p.slug}><ProductCard p={p} priority={i < priorityFirst} headingLevel={headingLevel} /></li>)}
    </ul>
  );
}
