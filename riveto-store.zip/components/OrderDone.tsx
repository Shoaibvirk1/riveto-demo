"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { rs } from "@/lib/format";

type Order = { id: string; total: number; shipping: number; whatsappUrl: string; name: string };

export default function OrderDone() {
  const [order, setOrder] = useState<Order | null | undefined>(undefined);
  useEffect(() => {
    try { setOrder(JSON.parse(sessionStorage.getItem("riveto-last-order") || "null")); } catch { setOrder(null); }
  }, []);
  if (order === undefined) return <p className="muted">Loading…</p>;
  if (!order) {
    return (
      <div className="empty">
        <h1>No recent order</h1>
        <p>We could not find an order placed in this browser tab.</p>
        <Link className="btn" href="/shop">Shop all styles</Link>
      </div>
    );
  }
  return (
    <div className="done">
      <h1>Thank you, {order.name.split(" ")[0]}!</h1>
      <p className="lede">Your order number is <b>{order.id}</b>. Total to pay on delivery: <b>{rs(order.total)}</b>.</p>
      <p>We will confirm your order on WhatsApp or by phone shortly. Please keep your phone on.</p>
      {order.whatsappUrl && (
        <p><a className="btn btn-wa" href={order.whatsappUrl} target="_blank" rel="noopener">Send my order on WhatsApp</a></p>
      )}
      <p><Link href="/shop">Continue shopping</Link></p>
    </div>
  );
}
