import Link from "next/link";
import { categories } from "@/lib/products";
import { site } from "@/lib/site";
import Icon from "./Icon";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="fcols">
          <div className="fbrand">
            <Link className="logo" href="/">{site.name.toLowerCase()}<span>.</span></Link>
            <p className="f-slogan">{site.slogan}</p>
            <p className="muted">{site.footerText}</p>
            <ul className="fbadges" aria-label="Why shop with us">
              <li><Icon name="cash" size={16} />Cash on Delivery</li>
              <li><Icon name="swap" size={16} />7-day exchange</li>
              <li><Icon name="truck" size={16} />Nationwide delivery</li>
            </ul>
          </div>
          <div>
            <h2 className="fh">Shop</h2>
            <ul className="fmenu">
              <li><Link href="/shop?sort=new">New arrivals</Link></li>
              {categories.map((c) => <li key={c.slug}><Link href={`/category/${c.slug}`}>{c.title}</Link></li>)}
              <li><Link href="/shop?sale=1">Sale</Link></li>
              <li><Link href="/shop">All styles</Link></li>
            </ul>
          </div>
          <div>
            <h2 className="fh">Help</h2>
            <ul className="fmenu">
              <li><Link href="/faq">FAQ</Link></li>
              <li><Link href="/shipping-policy">Shipping</Link></li>
              <li><Link href="/returns">Return and exchange</Link></li>
              <li><Link href="/about">About us</Link></li>
            </ul>
          </div>
          <div>
            <h2 className="fh">Policies</h2>
            <ul className="fmenu">
              <li><Link href="/privacy-policy">Privacy policy</Link></li>
              <li><Link href="/terms">Terms of service</Link></li>
            </ul>
          </div>
        </div>
        <div className="fbottom">© {year} {site.name}. Prices in PKR.</div>
      </div>
    </footer>
  );
}
