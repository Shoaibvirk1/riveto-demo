"use client";

import Link from "next/link";
import Icon from "./Icon";
import { useCart } from "./CartProvider";

export default function CartButton() {
  const { count, ready } = useCart();
  const label = ready && count ? `Cart, ${count} item${count === 1 ? "" : "s"}` : "Cart";
  return (
    <Link href="/cart" className="icon-btn cart-btn" aria-label={label}>
      <Icon name="bag" />
      {ready && count > 0 && <span className="count" aria-hidden="true">{count}</span>}
    </Link>
  );
}
