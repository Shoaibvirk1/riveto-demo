import Link from "next/link";
import { Suspense } from "react";
import { categories, products, mainImage } from "@/lib/products";
import { site } from "@/lib/site";
import { ActiveNav, NavList, type NavItem } from "./NavLinks";
import SearchBox, { type SearchItem } from "./SearchBox";
import CartButton from "./CartButton";
import Icon from "./Icon";

export const NAV: NavItem[] = [
  { href: "/shop?sort=new", label: "New arrivals" },
  ...categories.map((c) => ({ href: `/category/${c.slug}`, label: c.name })),
  { href: "/shop?sort=popular", label: "Best-sellers" },
  { href: "/shop?sale=1", label: "Sale", sale: true },
  { href: "/shop", label: "All styles" },
];

const searchIndex: SearchItem[] = products.map((p) => {
  const cat = categories.find((c) => c.slug === p.category)?.name || "";
  return {
    name: p.name, slug: p.slug, cat, price: p.minPrice, img: mainImage(p),
    words: [p.name, cat, p.colours.join(" "), p.tags.join(" "), p.short].join(" ").toLowerCase(),
  };
});

export default function Header() {
  return (
    <>
      <div className="announce" role="region" aria-label="Store announcements">
        <p>
          {site.announcement.map((a, i) => (
            <span key={a} className="announce-item">
              {i > 0 && <span className="announce-sep" aria-hidden="true" />}
              <Icon name={/cash|cod/i.test(a) ? "cash" : "truck"} size={18} />
              {a}
            </span>
          ))}
        </p>
      </div>
      <header className="site-header">
        <div className="wrap hdr">
          <Link className="logo" href="/" aria-label={`${site.name} home`}>
            {site.name.toLowerCase()}<span>.</span>
          </Link>
          <nav className="cats" aria-label="Main menu">
            <Suspense fallback={<NavList items={NAV} />}><ActiveNav items={NAV} /></Suspense>
          </nav>
          <div className="hdr-actions">
            <SearchBox index={searchIndex} />
            <CartButton />
          </div>
        </div>
        <nav className="cats-m" aria-label="Main menu, mobile">
          <Suspense fallback={<NavList items={NAV} />}><ActiveNav items={NAV} /></Suspense>
        </nav>
      </header>
    </>
  );
}
