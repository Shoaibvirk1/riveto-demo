"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import cartData from "@/data/cart.json";

type Row = [slug: string, name: string, size: string, colour: string, price: number, regular: number | null, stock: number, image: string];
const CATALOG = cartData as unknown as Record<string, Row>;

export type CartLine = {
  sku: string; qty: number; slug: string; name: string; size: string; colour: string;
  price: number; regular: number | null; stock: number; image: string;
};

type Ctx = {
  ready: boolean;
  lines: CartLine[];
  count: number;
  subtotal: number;
  add: (sku: string, qty?: number) => boolean;
  setQty: (sku: string, qty: number) => void;
  remove: (sku: string) => void;
  clear: () => void;
  toast: string;
};

const CartContext = createContext<Ctx | null>(null);
const KEY = "riveto-cart-v1";

export function lookup(sku: string) {
  const r = CATALOG[sku];
  return r ? { slug: r[0], name: r[1], size: r[2], colour: r[3], price: r[4], regular: r[5], stock: r[6], image: r[7] } : null;
}

export default function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Record<string, number>>({});
  const [ready, setReady] = useState(false);
  const [toast, setToast] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const itemsRef = useRef(items);
  itemsRef.current = items;

  // Load the saved cart after the page has rendered, so server and browser HTML match.
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY) || "{}");
      if (saved && typeof saved === "object") {
        const clean: Record<string, number> = {};
        for (const [sku, q] of Object.entries(saved)) {
          const v = lookup(sku);
          const n = Math.floor(Number(q));
          if (v && n > 0) clean[sku] = Math.min(n, v.stock);
        }
        setItems(clean);
      }
    } catch {}
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try { localStorage.setItem(KEY, JSON.stringify(items)); } catch {}
  }, [items, ready]);

  // Keep several open tabs in step.
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key !== KEY) return;
      try { setItems(JSON.parse(e.newValue || "{}")); } catch {}
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const say = useCallback((msg: string) => {
    setToast(msg);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(""), 2600);
  }, []);

  const add = useCallback((sku: string, qty = 1) => {
    const v = lookup(sku);
    if (!v || v.stock <= 0) return false;
    const have = itemsRef.current[sku] || 0;
    const next = Math.min(have + qty, v.stock);
    const ok = next > have;
    if (ok) setItems((cur) => ({ ...cur, [sku]: Math.min((cur[sku] || 0) + qty, v.stock) }));
    say(ok ? `Added to cart: ${v.name}, ${v.colour}, waist ${v.size}` : `Only ${v.stock} left in this size`);
    return ok;
  }, [say]);

  const setQty = useCallback((sku: string, qty: number) => {
    const v = lookup(sku);
    setItems((cur) => {
      const n = Math.max(0, Math.min(Math.floor(qty), v ? v.stock : 0));
      const next = { ...cur };
      if (n === 0) delete next[sku]; else next[sku] = n;
      return next;
    });
  }, []);

  const remove = useCallback((sku: string) => setQty(sku, 0), [setQty]);
  const clear = useCallback(() => setItems({}), []);

  const value = useMemo<Ctx>(() => {
    const lines: CartLine[] = Object.entries(items)
      .map(([sku, qty]) => { const v = lookup(sku); return v ? { sku, qty, ...v } : null; })
      .filter((l): l is CartLine => !!l);
    return {
      ready, lines, toast, add, setQty, remove, clear,
      count: lines.reduce((n, l) => n + l.qty, 0),
      subtotal: lines.reduce((n, l) => n + l.qty * l.price, 0),
    };
  }, [items, ready, toast, add, setQty, remove, clear]);

  return (
    <CartContext.Provider value={value}>
      {children}
      <div className="toast" role="status" aria-live="polite" data-show={toast ? "" : undefined}>{toast}</div>
    </CartContext.Provider>
  );
}

export function useCart() {
  const c = useContext(CartContext);
  if (!c) throw new Error("useCart must be used inside CartProvider");
  return c;
}
