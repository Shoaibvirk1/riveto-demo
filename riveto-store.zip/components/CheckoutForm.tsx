"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useCart } from "./CartProvider";
import { Totals } from "./CartView";
import { normalisePkPhone } from "@/lib/phone";
import { rs } from "@/lib/format";

type Errors = Partial<Record<"name" | "phone" | "city" | "address" | "email" | "form", string>>;

export default function CheckoutForm() {
  const { lines, subtotal, ready, clear } = useCart();
  const router = useRouter();
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState(false);

  if (!ready) return <p className="muted">Loading your cart…</p>;
  if (!lines.length) {
    return (
      <div className="empty">
        <p>Your cart is empty, so there is nothing to check out yet.</p>
        <Link className="btn" href="/shop">Shop all styles</Link>
      </div>
    );
  }

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const v = Object.fromEntries(fd) as Record<string, string>;
    const err: Errors = {};
    if ((v.name || "").trim().length < 2) err.name = "Enter your full name.";
    if (!normalisePkPhone(v.phone)) err.phone = "Enter a Pakistani mobile number, like 0300 1234567.";
    if ((v.city || "").trim().length < 2) err.city = "Enter your city.";
    if ((v.address || "").trim().length < 8) err.address = "Enter your full address: house number, street and area.";
    if (v.email && !/^\S+@\S+\.\S+$/.test(v.email)) err.email = "Enter a valid email, or leave it empty.";
    setErrors(err);
    if (Object.keys(err).length) {
      const first = Object.keys(err)[0];
      (e.currentTarget.elements.namedItem(first) as HTMLElement | null)?.focus();
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...v, items: lines.map((l) => ({ sku: l.sku, qty: l.qty })) }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrors(data.errors || { form: data.error || "We could not place your order. Please try again." });
        setBusy(false);
        return;
      }
      sessionStorage.setItem("riveto-last-order", JSON.stringify(data.order));
      clear();
      router.push("/order");
    } catch {
      setErrors({ form: "No internet connection. Check your connection and place your order again." });
      setBusy(false);
    }
  };

  const field = (name: keyof Errors, label: string, props: React.InputHTMLAttributes<HTMLInputElement> & { as?: "textarea" }, note?: string) => {
    const id = `f-${name}`;
    const { as, ...rest } = props;
    const common = { id, name, "aria-invalid": !!errors[name] || undefined, "aria-describedby": errors[name] ? `${id}-err` : note ? `${id}-note` : undefined };
    return (
      <div className={`field${errors[name] ? " has-error" : ""}`}>
        <label htmlFor={id}>{label}</label>
        {as === "textarea"
          ? <textarea {...common} rows={3} required={rest.required} placeholder={rest.placeholder} autoComplete={rest.autoComplete} />
          : <input {...common} {...rest} />}
        {note && !errors[name] && <small id={`${id}-note`} className="note">{note}</small>}
        {errors[name] && <small id={`${id}-err`} className="err">{errors[name]}</small>}
      </div>
    );
  };

  return (
    <form className="checkout" onSubmit={submit} noValidate>
      <div className="co-fields">
        <h2>Delivery details</h2>
        {field("name", "Full name", { required: true, autoComplete: "name" })}
        {field("phone", "Mobile number", { required: true, type: "tel", inputMode: "tel", autoComplete: "tel", placeholder: "03XX XXXXXXX" }, "We will confirm your order on this number.")}
        {field("city", "City", { required: true, autoComplete: "address-level2", placeholder: "e.g. Lahore" })}
        {field("address", "Full address", { required: true, as: "textarea", autoComplete: "street-address", placeholder: "House no., street, area" })}
        {field("email", "Email for order updates (optional)", { type: "email", autoComplete: "email" })}
        <div className="field">
          <label htmlFor="f-note">Order note (optional)</label>
          <input id="f-note" name="note" maxLength={300} placeholder="e.g. Call before delivery" />
        </div>
        {/* Bots fill every field; people never see this one. */}
        <div className="hp" aria-hidden="true"><label htmlFor="f-website">Website</label><input id="f-website" name="website" tabIndex={-1} autoComplete="off" /></div>
        <fieldset className="pay">
          <legend>Payment</legend>
          <label className="pay-opt"><input type="radio" name="payment" value="cod" defaultChecked /> <span><b>Cash on Delivery</b><small>Pay the rider in cash when your parcel arrives.</small></span></label>
        </fieldset>
      </div>
      <aside className="summary" aria-label="Your order">
        <h2>Your order</h2>
        <ul className="mini-lines">
          {lines.map((l) => <li key={l.sku}><span>{l.name}<small>{l.colour} · Waist {l.size} · ×{l.qty}</small></span><b>{rs(l.price * l.qty)}</b></li>)}
        </ul>
        <Totals subtotal={subtotal} />
        {errors.form && <p className="err form-err" role="alert">{errors.form}</p>}
        <button className="btn btn-accent btn-block" type="submit" disabled={busy}>{busy ? "Placing your order…" : "Place order"}</button>
        <p className="muted small">By placing your order you agree to our <Link href="/terms">terms</Link>. We will confirm on WhatsApp or by phone before shipping.</p>
      </aside>
    </form>
  );
}
