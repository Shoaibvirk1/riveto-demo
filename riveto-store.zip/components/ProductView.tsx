"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { ListProduct } from "@/lib/product-utils";
import { rs } from "@/lib/format";
import { useCart } from "./CartProvider";
import ProductImage from "./ProductImage";
import Icon from "./Icon";

type Props = { p: ListProduct; categoryName: string; whatsapp: string; trust: { delivery: string; exchange: string } };

export default function ProductView({ p, categoryName, whatsapp, trust }: Props) {
  const { add } = useCart();
  const firstLive = p.colours.find((c) => p.variants.some((v) => v.colour === c && v.stock > 0)) || p.colours[0] || "";
  const [colour, setColour] = useState(firstLive);
  const [size, setSize] = useState("");
  const [qty, setQty] = useState(1);
  const [hint, setHint] = useState("");
  const [showSticky, setShowSticky] = useState(false);
  const buyBtn = useRef<HTMLButtonElement>(null);
  const sizeGroup = useRef<HTMLDivElement>(null);

  // Links like /product/x?colour=Mid%20blue&size=32 (used in Google Shopping data) pre-select the option.
  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    const c = q.get("colour"), s = q.get("size");
    if (c && p.colours.includes(c)) setColour(c);
    if (s && p.sizes.includes(s)) setSize(s);
  }, [p.colours, p.sizes]);

  useEffect(() => {
    const el = buyBtn.current;
    if (!el || !("IntersectionObserver" in window)) return;
    const io = new IntersectionObserver(([e]) => setShowSticky(!e.isIntersecting && e.boundingClientRect.top < 0));
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const variant = useMemo(() => p.variants.find((v) => v.colour === colour && v.size === size), [p.variants, colour, size]);
  const stockFor = (s: string) => p.variants.find((v) => v.colour === colour && v.size === s)?.stock ?? 0;
  const image = p.images[0] || p.art[colour] || Object.values(p.art)[0];
  const price = variant?.price ?? p.minPrice;
  const regular = variant ? variant.regular : p.regularPrice;
  const onSale = regular != null && regular > price;

  const pickColour = (c: string) => {
    setColour(c);
    if (size && !(p.variants.find((v) => v.colour === c && v.size === size)?.stock)) setSize("");
  };

  const addToCart = () => {
    if (!size) {
      setHint("Choose your waist size first.");
      sizeGroup.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      sizeGroup.current?.querySelector<HTMLButtonElement>("button:not(:disabled)")?.focus();
      return;
    }
    if (!variant || variant.stock <= 0) { setHint("This size is sold out. Pick another size."); return; }
    setHint("");
    add(variant.sku, qty);
  };

  const askText = `Hi! I have a question about ${p.name}${colour ? ` in ${colour}` : ""}${size ? `, waist ${size}` : ""}.`;
  const lowStock = variant && variant.stock > 0 && variant.stock <= 3;

  return (
    <div className="pdp">
      <div className={`pdp-gallery tone-${p.category}`}>
        <ProductImage src={image} alt={`${p.name}${colour ? ` in ${colour}` : ""}`} sizes="(max-width: 899px) 100vw, 50vw" priority />
        {onSale && <span className="badge sale">Sale</span>}
      </div>

      <div className="pdp-info">
        <p className="pdp-cat">{categoryName}</p>
        <h1>{p.name}</h1>
        <p className="pdp-price">
          {onSale && <del>{rs(regular!)}</del>} <ins>{rs(price)}</ins>
          {onSale && <span className="save">Save {rs(regular! - price)}</span>}
        </p>

        {p.colours.length > 0 && (
          <fieldset className="opt">
            <legend>Colour: <b>{colour}</b></legend>
            <div className="chips">
              {p.colours.map((c) => {
                const live = p.variants.some((v) => v.colour === c && v.stock > 0);
                return (
                  <button key={c} type="button" className="chip" aria-pressed={c === colour} disabled={!live} onClick={() => pickColour(c)}>
                    {c}
                  </button>
                );
              })}
            </div>
          </fieldset>
        )}

        {p.sizes.length > 0 && (
          <fieldset className="opt">
            <legend>Waist size{size ? <>: <b>{size}</b></> : ""}</legend>
            <div className="chips" ref={sizeGroup}>
              {p.sizes.map((s) => {
                const left = stockFor(s);
                return (
                  <button key={s} type="button" className="chip chip-size" aria-pressed={s === size} disabled={left <= 0}
                    aria-label={left <= 0 ? `${s}, sold out` : `Waist ${s}`} onClick={() => { setSize(s); setHint(""); }}>
                    {s}
                  </button>
                );
              })}
            </div>
            <details className="size-guide">
              <summary>Size guide</summary>
              <table>
                <thead><tr><th scope="col">Size</th><th scope="col">Waist (in)</th><th scope="col">Waist (cm)</th></tr></thead>
                <tbody>{p.sizes.map((s) => <tr key={s}><td>{s}</td><td>{s}</td><td>{Math.round(Number(s) * 2.54)}</td></tr>)}</tbody>
              </table>
              <p>Sizes are real waist measurements. Between sizes? Pick the larger one.</p>
            </details>
          </fieldset>
        )}

        {lowStock && <p className="low">Only {variant!.stock} left in this size</p>}

        <div className="buy-row">
          <div className="qty" role="group" aria-label="Quantity">
            <button type="button" aria-label="Decrease quantity" onClick={() => setQty((q) => Math.max(1, q - 1))}>−</button>
            <input type="number" inputMode="numeric" min={1} max={variant?.stock || 10} value={qty} aria-label="Quantity"
              onChange={(e) => setQty(Math.max(1, Math.min(Number(e.target.value) || 1, variant?.stock || 10)))} />
            <button type="button" aria-label="Increase quantity" onClick={() => setQty((q) => Math.min(q + 1, variant?.stock || 10))}>+</button>
          </div>
          <button ref={buyBtn} type="button" className="btn btn-accent btn-buy" onClick={addToCart} disabled={!p.inStock}>
            {p.inStock ? "Add to cart" : "Sold out"}
          </button>
        </div>
        <p className="hint" role="alert">{hint}</p>

        <ul className="pdp-trust">
          <li><Icon name="cash" /><span><b>Cash on Delivery</b><small>Pay when it reaches you</small></span></li>
          <li><Icon name="truck" /><span><b>{trust.delivery}</b><small>All over Pakistan</small></span></li>
          <li><Icon name="swap" /><span><b>{trust.exchange}</b><small>Wrong size? We will swap it</small></span></li>
          {whatsapp && (
            <li><Icon name="whatsapp" /><span><b><a href={`${whatsapp}?text=${encodeURIComponent(askText)}`} target="_blank" rel="noopener">Ask on WhatsApp</a></b><small>Quick replies</small></span></li>
          )}
        </ul>
      </div>

      <div className={`sticky-buy${showSticky ? " show" : ""}`} aria-hidden={!showSticky}>
        <span className="sb-info"><b>{p.name}</b><span>{rs(price)}{size ? ` · Waist ${size}` : ""}</span></span>
        <button type="button" className="btn btn-accent" tabIndex={showSticky ? 0 : -1} onClick={addToCart} disabled={!p.inStock}>Add to cart</button>
      </div>
    </div>
  );
}
