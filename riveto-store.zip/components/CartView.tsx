"use client";

import Link from "next/link";
import { useCart } from "./CartProvider";
import { rs } from "@/lib/format";
import { shippingFor } from "@/lib/cart-math";
import { site } from "@/lib/site";
import ProductImage from "./ProductImage";
import Icon from "./Icon";

export function Totals({ subtotal }: { subtotal: number }) {
  const ship = shippingFor(subtotal);
  const toFree = site.shipping.freeOver - subtotal;
  return (
    <dl className="totals">
      <div><dt>Subtotal</dt><dd>{rs(subtotal)}</dd></div>
      <div><dt>Delivery</dt><dd>{ship ? rs(ship) : "Free"}</dd></div>
      <div className="grand"><dt>Total</dt><dd>{rs(subtotal + ship)}</dd></div>
      {toFree > 0 && subtotal > 0 && <p className="free-note">Add {rs(toFree)} more for free delivery.</p>}
    </dl>
  );
}

export default function CartView() {
  const { lines, subtotal, setQty, remove, ready } = useCart();
  if (!ready) return <p className="muted">Loading your cart…</p>;
  if (!lines.length) {
    return (
      <div className="empty">
        <p>Your cart is empty. Find your next favourite pair.</p>
        <Link className="btn" href="/shop">Shop all styles</Link>
      </div>
    );
  }
  return (
    <div className="cart-layout">
      <ul className="cart-lines">
        {lines.map((l) => (
          <li key={l.sku} className="cart-line">
            <Link href={`/product/${l.slug}`} className="cl-pic"><ProductImage src={l.image} alt={l.name} sizes="96px" /></Link>
            <div className="cl-info">
              <Link href={`/product/${l.slug}`}><b>{l.name}</b></Link>
              <small>{l.colour} · Waist {l.size}</small>
              <span className="cl-price">{rs(l.price)}</span>
            </div>
            <div className="qty" role="group" aria-label={`Quantity of ${l.name}`}>
              <button type="button" aria-label="Decrease quantity" onClick={() => setQty(l.sku, l.qty - 1)}>−</button>
              <output aria-live="polite">{l.qty}</output>
              <button type="button" aria-label="Increase quantity" disabled={l.qty >= l.stock} onClick={() => setQty(l.sku, l.qty + 1)}>+</button>
            </div>
            <span className="cl-total">{rs(l.qty * l.price)}</span>
            <button type="button" className="icon-btn cl-remove" aria-label={`Remove ${l.name} from cart`} onClick={() => remove(l.sku)}><Icon name="trash" size={20} /></button>
          </li>
        ))}
      </ul>
      <aside className="summary" aria-label="Order summary">
        <h2>Order summary</h2>
        <Totals subtotal={subtotal} />
        <Link className="btn btn-accent btn-block" href="/checkout">Checkout, pay on delivery</Link>
        <Link className="link-back" href="/shop">Continue shopping</Link>
      </aside>
    </div>
  );
}
