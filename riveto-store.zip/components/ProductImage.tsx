import Image from "next/image";

/** Real photos go through Next's image optimiser; the drawn SVG placeholders are served as they are. */
export default function ProductImage({ src, alt, sizes, priority = false, className = "" }: {
  src: string; alt: string; sizes: string; priority?: boolean; className?: string;
}) {
  const svg = src.endsWith(".svg");
  return (
    <Image
      src={src}
      alt={alt}
      width={svg ? 216 : 1200}
      height={svg ? 468 : 1500}
      sizes={sizes}
      priority={priority}
      unoptimized={svg}
      className={`${svg ? "art" : "photo"} ${className}`}
    />
  );
}
