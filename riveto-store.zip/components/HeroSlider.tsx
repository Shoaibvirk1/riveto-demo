"use client";

import Link from "next/link";
import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Slide } from "@/lib/home";
import Icon from "./Icon";

export default function HeroSlider({ slides, seconds }: { slides: Slide[]; seconds: number }) {
  const [i, setI] = useState(0);
  const paused = useRef(false);
  const x0 = useRef<number | null>(null);
  const n = slides.length;
  const go = useCallback((k: number) => setI(((k % n) + n) % n), [n]);

  useEffect(() => {
    if (n < 2 || seconds <= 0) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = setInterval(() => { if (!paused.current && !document.hidden) setI((c) => (c + 1) % n); }, seconds * 1000);
    return () => clearInterval(t);
  }, [n, seconds, i]);

  return (
    <section
      className="hero"
      aria-roledescription="carousel"
      aria-label="Featured collections"
      onMouseEnter={() => (paused.current = true)}
      onMouseLeave={() => (paused.current = false)}
      onFocus={() => (paused.current = true)}
      onBlur={() => (paused.current = false)}
      onTouchStart={(e) => { x0.current = e.touches[0].clientX; paused.current = true; }}
      onTouchEnd={(e) => {
        if (x0.current === null) return;
        const dx = e.changedTouches[0].clientX - x0.current;
        x0.current = null; paused.current = false;
        if (Math.abs(dx) > 40) go(i + (dx < 0 ? 1 : -1));
      }}
    >
      <div className="hero-view">
        <div className="hero-track" style={{ transform: `translateX(${-100 * i}%)` }}>
          {slides.map((s, k) => (
            <div
              key={s.title}
              className={`hero-slide ${s.photo ? "has-photo" : s.theme}`}
              role="group"
              aria-roledescription="slide"
              aria-label={`${k + 1} of ${n}`}
              aria-hidden={k !== i}
              inert={k !== i}
            >
              {s.photo && <Image src={s.photo} alt="" fill sizes="100vw" priority={k === 0} className="hero-photo" />}
              <div className="wrap hero-in">
                <div className="hero-copy">
                  {k === 0 ? <h1>{s.title}</h1> : <h2 className="hero-h">{s.title}</h2>}
                  <p>{s.text}</p>
                  <div className="hero-cta">
                    <Link className="btn btn-accent" href={s.href}>{s.button}</Link>
                    <Link className="btn btn-ghost" href="/shop">Explore all styles</Link>
                  </div>
                </div>
                {!s.photo && (
                  <div className="hero-art" aria-hidden="true">
                    {s.art.map((src, f) => (
                      <Image key={src} className={`fan f${f + 1}`} src={src} alt="" width={216} height={468} unoptimized priority={k === 0} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      {n > 1 && (
        <>
          <button type="button" className="hero-nav prev" aria-label="Previous slide" onClick={() => go(i - 1)}><Icon name="left" size={20} /></button>
          <button type="button" className="hero-nav next" aria-label="Next slide" onClick={() => go(i + 1)}><Icon name="right" size={20} /></button>
          <div className="hero-dots">
            {slides.map((s, k) => (
              <button key={s.title} type="button" aria-label={`Show slide ${k + 1}`} aria-current={k === i ? "true" : undefined} onClick={() => go(k)} />
            ))}
          </div>
        </>
      )}
    </section>
  );
}
