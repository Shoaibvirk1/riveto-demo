"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";

export type NavItem = { href: string; label: string; sale?: boolean };

/** Marks the link for the page you are on, including shop links with filters like ?sort=new. */
export function ActiveNav({ items }: { items: NavItem[] }) {
  const path = usePathname();
  const qs = useSearchParams().toString();
  const here = path + (qs ? `?${qs}` : "");
  return <NavList items={items} here={here} />;
}

export function NavList({ items, here = "" }: { items: NavItem[]; here?: string }) {
  return (
    <ul>
      {items.map((it) => (
        <li key={it.href}>
          <Link href={it.href} className={it.sale ? "is-sale" : undefined} aria-current={here === it.href ? "page" : undefined}>
            {it.label}
          </Link>
        </li>
      ))}
    </ul>
  );
}
