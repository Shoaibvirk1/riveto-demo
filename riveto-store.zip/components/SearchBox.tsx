"use client";

import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect, useId, useMemo, useRef, useState } from "react";
import Icon from "./Icon";
import { rs } from "@/lib/format";

export type SearchItem = { name: string; slug: string; cat: string; price: number; img: string; words: string };

export default function SearchBox({ index }: { index: SearchItem[] }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const input = useRef<HTMLInputElement>(null);
  const toggle = useRef<HTMLButtonElement>(null);
  const router = useRouter();
  const listId = useId();

  const hits = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (t.length < 2) return [];
    const parts = t.split(/\s+/);
    return index.filter((it) => parts.every((p) => it.words.includes(p))).slice(0, 5);
  }, [q, index]);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => input.current?.focus(), 30);
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") { setOpen(false); toggle.current?.focus(); } };
    document.addEventListener("keydown", onKey);
    document.body.classList.add("searching");
    return () => { clearTimeout(t); document.removeEventListener("keydown", onKey); document.body.classList.remove("searching"); };
  }, [open]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const t = q.trim();
    if (!t) return;
    setOpen(false);
    router.push(`/search?q=${encodeURIComponent(t)}`);
  };

  return (
    <>
      <button ref={toggle} type="button" className="search-pill" aria-expanded={open} aria-controls="searchBar" onClick={() => setOpen((o) => !o)}>
        <Icon name="search" size={20} />
        <span>Search</span>
      </button>
      {open && (
        <>
          <div className="search-scrim" onClick={() => setOpen(false)} />
          <div className="searchbar" id="searchBar">
            <div className="wrap">
              <form className="search-form" role="search" action="/search" onSubmit={submit}>
                <label htmlFor="q" className="sr">Search products</label>
                <input
                  ref={input} id="q" name="q" type="search" autoComplete="off" value={q}
                  onChange={(e) => setQ(e.target.value)} placeholder="Try slim, cargo or black"
                  aria-controls={listId} aria-autocomplete="list"
                />
                <button className="btn" type="submit">Search</button>
                <button className="icon-x" type="button" aria-label="Close search" onClick={() => setOpen(false)}><Icon name="close" /></button>
              </form>
              {q.trim().length >= 2 && (
                <div className="sb-results" id={listId}>
                  {hits.length === 0 && <p className="sb-none">No products match “{q.trim()}”. Try slim, cargo or black.</p>}
                  {hits.map((h) => (
                    <Link key={h.slug} href={`/product/${h.slug}`} className="sb-item" onClick={() => setOpen(false)}>
                      <span className="sb-th"><Image src={h.img} alt="" width={36} height={78} unoptimized={h.img.endsWith(".svg")} /></span>
                      <span className="sb-tx"><b>{h.name}</b><small>{h.cat}</small></span>
                      <span className="sb-pr">{rs(h.price)}</span>
                    </Link>
                  ))}
                  {hits.length > 0 && <Link className="sb-all" href={`/search?q=${encodeURIComponent(q.trim())}`} onClick={() => setOpen(false)}>See all results for “{q.trim()}”</Link>}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </>
  );
}
