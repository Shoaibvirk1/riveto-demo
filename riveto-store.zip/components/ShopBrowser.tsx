"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useRef } from "react";
import type { ListProduct } from "@/lib/product-utils";
import { applyFilters, colourKey, headingFor, PRICE_BANDS, readFilters, SORTS } from "@/lib/filter";
import { ProductGrid } from "./ProductCard";

type Props = { all: ListProduct[]; title: string; intro?: string; showSearchHint?: boolean };

/** Filters live in the URL (?size=32&colour=mid-blue), so every filtered view can be shared or bookmarked. */
export default function ShopBrowser({ all, title, intro, showSearchHint }: Props) {
  const sp = useSearchParams();
  const path = usePathname();
  const router = useRouter();
  const f = useMemo(() => readFilters(new URLSearchParams(sp.toString())), [sp]);
  const shown = useMemo(() => applyFilters(all, f), [all, f]);
  const bar = useRef<HTMLDivElement>(null);

  const sizes = useMemo(() => [...new Set(all.flatMap((p) => p.sizes))].sort((a, b) => Number(a) - Number(b)), [all]);
  const colours = useMemo(() => [...new Set(all.flatMap((p) => p.colours))].sort(), [all]);

  const href = (key: string, value: string, multi: boolean) => {
    const next = new URLSearchParams(sp.toString());
    const cur = (next.get(key) || "").split(",").filter(Boolean);
    let vals = cur.includes(value) ? cur.filter((v) => v !== value) : multi ? [...cur, value] : [value];
    if (!value) vals = [];
    if (vals.length) next.set(key, vals.join(",")); else next.delete(key);
    const qs = next.toString();
    return qs ? `${path}?${qs}` : path;
  };

  // Close other dropdowns when one opens, and all of them on outside click or Escape.
  useEffect(() => {
    const root = bar.current;
    if (!root) return;
    const drops = () => Array.from(root.querySelectorAll<HTMLDetailsElement>("details"));
    const onToggle = (e: Event) => {
      const d = e.target as HTMLDetailsElement;
      if (d.open) drops().forEach((o) => { if (o !== d) o.open = false; });
    };
    const onClick = (e: MouseEvent) => { if (!root.contains(e.target as Node)) drops().forEach((d) => (d.open = false)); };
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") drops().forEach((d) => (d.open = false)); };
    root.addEventListener("toggle", onToggle, true);
    document.addEventListener("click", onClick);
    document.addEventListener("keydown", onKey);
    return () => { root.removeEventListener("toggle", onToggle, true); document.removeEventListener("click", onClick); document.removeEventListener("keydown", onKey); };
  }, []);

  // Close the dropdown after choosing an option.
  useEffect(() => { bar.current?.querySelectorAll("details").forEach((d) => (d.open = false)); }, [sp]);

  const active = f.size.length + f.colour.length + (f.price ? 1 : 0) + (f.sale ? 1 : 0) + (f.stock ? 1 : 0);

  const drop = (label: string, k: string, opts: { id: string; label: string }[], multi = true) => {
    const cur = (sp.get(k) || "").split(",").filter(Boolean);
    return (
      <details key={k} className={`fdrop${cur.length ? " is-active" : ""}`}>
        <summary>{label}{cur.length > 0 && <span className="fcount">{cur.length}</span>}<span className="chev" aria-hidden="true" /></summary>
        <div className="fpanel" role="group" aria-label={label}>
          {opts.map((o) => {
            const on = cur.includes(o.id);
            return (
              <Link key={o.id} href={href(k, o.id, multi)} scroll={false} className={`fopt${on ? " on" : ""}`} aria-pressed={on} rel="nofollow">
                <span className="fbox" aria-hidden="true" />{o.label}
              </Link>
            );
          })}
        </div>
      </details>
    );
  };

  return (
    <>
      <header className="page-head">
        <h1>{headingFor(f, title)}</h1>
        {intro && !active && !f.sort && !f.q && <p className="lede">{intro}</p>}
      </header>
      <div className="fbar" ref={bar} role="region" aria-label="Filter products">
        {drop("Size", "size", sizes.map((s) => ({ id: s, label: s })))}
        {drop("Colour", "colour", colours.map((c) => ({ id: colourKey(c), label: c })))}
        {drop("Price", "price", PRICE_BANDS, false)}
        {drop("Availability", "stock", [{ id: "in", label: "In stock" }, { id: "out", label: "Sold out" }], false)}
        {f.sale && <Link className="fchip" href={href("sale", "", false)} scroll={false}>Sale ✕</Link>}
        {active > 0 && <Link className="fclear" href={f.q ? `${path}?q=${encodeURIComponent(f.q)}` : path} scroll={false}>Clear filters</Link>}
        <label className="fsort">
          <span className="sr">Sort by</span>
          <select value={f.sort} onChange={(e) => router.push(href("sort", e.target.value, false), { scroll: false })}>
            {SORTS.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
          </select>
        </label>
      </div>
      <p className="results" aria-live="polite">{shown.length} {shown.length === 1 ? "style" : "styles"}</p>
      {shown.length ? (
        <ProductGrid list={shown} priorityFirst={4} headingLevel={2} />
      ) : (
        <div className="empty">
          <p>{f.q ? `Nothing matches “${f.q}”.` : "No styles match these filters."} {showSearchHint ? "Try slim, cargo or black." : "Remove a filter to see more."}</p>
          <Link className="btn" href="/shop">See all styles</Link>
        </div>
      )}
    </>
  );
}
