"use client";

import { useCart } from "./CartProvider";

type Opt = { sku: string; size: string };

/** Tap a size under the card and it goes straight into the cart. */
export default function QuickAdd({ name, colour, options }: { name: string; colour: string; options: Opt[] }) {
  const { add } = useCart();
  if (!options.length) return null;
  return (
    <div className="quick-add">
      <span className="qa-label">Quick add <small>{colour}</small></span>
      <span className="qa-sizes">
        {options.map((o) => (
          <button key={o.sku} type="button" className="qa-size" onClick={() => add(o.sku)} aria-label={`Add ${name}, ${colour}, waist ${o.size} to cart`}>
            {o.size}
          </button>
        ))}
      </span>
    </div>
  );
}
