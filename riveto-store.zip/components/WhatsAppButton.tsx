import { whatsappLink } from "@/lib/site";
import Icon from "./Icon";

export default function WhatsAppButton() {
  const href = whatsappLink("Hi! I have a question about my order.");
  if (!href) return null;
  return (
    <a className="wa-float" href={href} target="_blank" rel="noopener" aria-label="Chat with us on WhatsApp">
      <Icon name="whatsapp" size={28} />
    </a>
  );
}
