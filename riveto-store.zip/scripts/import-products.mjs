// Turns data/products.csv (a WooCommerce product export) into data/products.json.
// Run after editing the CSV:  npm run import-products
import { readFileSync, writeFileSync } from "node:fs";

const SRC = new URL("../data/products.csv", import.meta.url);
const OUT = new URL("../data/products.json", import.meta.url);

/** RFC 4180 CSV parser: handles quotes, escaped quotes and line breaks inside fields. */
function parseCsv(text) {
  const rows = [];
  let row = [], field = "", quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') quoted = false;
      else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ",") { row.push(field); field = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field); rows.push(row); row = []; field = "";
    } else field += c;
  }
  if (field !== "" || row.length) { row.push(field); rows.push(row); }
  const [head, ...body] = rows.filter((r) => r.some((v) => v.trim() !== ""));
  return body.map((r) => Object.fromEntries(head.map((h, i) => [h.trim(), (r[i] ?? "").trim()])));
}

const slugify = (s) =>
  s.toLowerCase().replace(/&/g, " ").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
const num = (v) => (v === "" || v == null ? null : Number(v));
const text = (v) => (v || "").replace(/\\n/g, "\n").trim();

// Short, search-friendly introductions for each category page.
const CATEGORY_INFO = {
  men: {
    title: "Men's jeans",
    intro: "Slim, straight and relaxed jeans for men in real waist sizes 28 to 38. Soft cotton denim with a little stretch, Cash on Delivery across Pakistan and an easy 7-day size exchange.",
  },
  women: {
    title: "Women's jeans",
    intro: "High-rise skinny, wide-leg and mom jeans for women in waist sizes 24 to 34. Comfortable stretch denim, Cash on Delivery across Pakistan and an easy 7-day size exchange.",
  },
  "cargo-pants": {
    title: "Cargo pants",
    intro: "Cargo pants with roomy pockets in tough cotton, parachute and denim. Everyday fits in waist sizes 28 to 38, delivered anywhere in Pakistan with Cash on Delivery.",
  },
  "chinos-trousers": {
    title: "Chinos and trousers",
    intro: "Clean chinos and pleated trousers for work and weekends. Easy cotton fabrics in neutral colours, waist sizes 28 to 38, Cash on Delivery across Pakistan.",
  },
};

// Drawn trousers used until real photos are added, picked by category and colour.
function artFor(category, colour) {
  const c = colour.toLowerCase();
  if (category === "cargo-pants") {
    if (/stone|khaki|ecru/.test(c)) return "/img/hero-2-2.svg";
    return "/img/hero-2-1.svg";
  }
  if (category === "chinos-trousers") {
    if (/stone/.test(c)) return "/img/hero-3-2.svg";
    if (/charcoal|black/.test(c)) return "/img/hero-3-3.svg";
    return "/img/hero-3-1.svg";
  }
  if (/light|ecru/.test(c)) return "/img/hero-1-1.svg";
  if (/raw|indigo/.test(c)) return "/img/hero-1-2.svg";
  if (/black/.test(c)) return "/img/hero-2-3.svg";
  return "/img/hero-1-3.svg";
}

const rows = parseCsv(readFileSync(SRC, "utf8"));
const parents = rows.filter((r) => r.Type === "variable" || r.Type === "simple");
const variations = rows.filter((r) => r.Type === "variation");

const categories = new Map();
const products = parents
  .filter((p) => p.Published !== "0" && p.Published !== "-1")
  .map((p, index) => {
    const catName = (p.Categories || "Uncategorized").split(",")[0].split(">").pop().trim();
    const catSlug = slugify(catName);
    if (!categories.has(catSlug)) {
      const info = CATEGORY_INFO[catSlug] || {};
      categories.set(catSlug, { slug: catSlug, name: catName, title: info.title || catName, intro: info.intro || "" });
    }

    let variants = variations
      .filter((v) => v.Parent === p.SKU)
      .map((v) => ({
        sku: v.SKU,
        size: v["Attribute 1 value(s)"],
        colour: v["Attribute 2 value(s)"],
        regular: num(v["Regular price"]),
        sale: num(v["Sale price"]),
        stock: v.Stock === "" ? 99 : Math.max(0, Number(v.Stock)),
      }));
    if (!variants.length) {
      variants = [{ sku: p.SKU, size: "", colour: "", regular: num(p["Regular price"]), sale: num(p["Sale price"]), stock: p.Stock === "" ? 99 : Number(p.Stock) }];
    }
    variants = variants.map((v) => ({ ...v, price: v.sale ?? v.regular }));

    const sizes = [...new Set(variants.map((v) => v.size).filter(Boolean))].sort((a, b) => Number(a) - Number(b));
    const colours = [...new Set(variants.map((v) => v.colour).filter(Boolean))];
    const prices = variants.map((v) => v.price);
    const images = (p.Images || "").split(",").map((s) => s.trim()).filter(Boolean);
    const art = Object.fromEntries(colours.map((c) => [c, artFor(catSlug, c)]));

    return {
      slug: slugify(p.Name),
      sku: p.SKU,
      name: p.Name,
      category: catSlug,
      featured: p["Is featured?"] === "1",
      tags: (p.Tags || "").split(",").map((t) => t.trim()).filter(Boolean),
      short: text(p["Short description"]),
      description: text(p.Description),
      weightKg: num(p["Weight (kg)"]),
      sizes,
      colours,
      minPrice: Math.min(...prices),
      maxPrice: Math.max(...prices),
      regularPrice: Math.max(...variants.map((v) => v.regular ?? v.price)),
      onSale: variants.some((v) => v.sale != null && v.sale < (v.regular ?? Infinity)),
      inStock: variants.some((v) => v.stock > 0),
      images,
      art: colours.length ? art : { "": artFor(catSlug, "") },
      order: index,
      variants,
    };
  });

const data = { generated: new Date().toISOString(), categories: [...categories.values()], products };
writeFileSync(OUT, JSON.stringify(data, null, 1) + "\n");

// Slim lookup the browser downloads once (and caches) for the cart and checkout.
const cart = {};
for (const p of products) {
  for (const v of p.variants) {
    cart[v.sku] = [p.slug, p.name, v.size, v.colour, v.price, v.regular, v.stock, p.images[0] || p.art[v.colour] || Object.values(p.art)[0]];
  }
}
writeFileSync(new URL("../data/cart.json", import.meta.url), JSON.stringify(cart) + "\n");
console.log(`Imported ${products.length} products, ${products.reduce((n, p) => n + p.variants.length, 0)} variants, ${categories.size} categories -> data/products.json`);
