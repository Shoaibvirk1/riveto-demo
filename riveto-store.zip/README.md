# Riveto store (Next.js)

Fast, search-engine-ready store for jeans, cargo pants and chinos, with Cash on Delivery across Pakistan.
Same design and products as the Riveto WordPress theme, rebuilt so it runs **free on Vercel**.

## What's inside

- **Pages:** home (banner slider, trending, categories, best-sellers, new arrivals), shop with Size / Colour / Price / Availability filters and sorting, 4 category pages, 12 product pages, search, cart, checkout, order confirmation, FAQ, shipping, returns, about, privacy and terms.
- **Shopping:** size and colour buttons (sold-out sizes are crossed out), quick add from product cards, cart saved in the browser, sticky "Add to cart" on phones.
- **Checkout:** name, mobile, city, address and optional email. Pakistani mobile numbers are checked and saved as `03001234567`. Delivery is Rs 250, free over Rs 5,000. Prices and stock are always re-checked on the server.
- **Orders:** every order gets a number like `RV-261007-K4QX`, is written to the Vercel logs, can be sent to a Google Sheet (see below), and the customer gets a button to send it to your WhatsApp.

## SEO built in

- Every page is pre-built as static HTML, so it loads fast and search engines read everything.
- Unique title, description and canonical link on every page; filtered and sorted views point back to one address.
- Open Graph and Twitter previews for WhatsApp, Facebook and X (1200 × 630 share image).
- Structured data for Google rich results: Online store, Website search box, Breadcrumbs, Product groups with every size and colour (price, stock, delivery cost and time, 7-day return policy), Item lists and FAQ.
- `sitemap.xml` with product images, `robots.txt` (cart, checkout and search kept out of Google; preview deployments fully hidden), web manifest and favicon.
- One `<h1>` per page, ordered headings, image alt text, `lang="en-PK"`. Lighthouse SEO, accessibility and best-practices all score 100.

## Put it online free (Vercel)

1. **GitHub:** create a new **public or private** repository, e.g. `riveto-store`. Click **uploading an existing file**, drag in **everything inside this folder** (not the folder itself), then **Commit changes**.
2. **Vercel:** go to vercel.com, **Sign up with GitHub** (free Hobby plan), click **Add New → Project**, and **Import** `riveto-store`.
3. Before clicking **Deploy**, open **Environment Variables** and add:
   - `NEXT_PUBLIC_WHATSAPP` = your WhatsApp number, e.g. `03001234567`
4. Click **Deploy**. In about a minute you get a free link like `https://riveto-store.vercel.app`. That is your shareable link.

Every time you change a file on GitHub, Vercel rebuilds the site by itself.

### Optional settings (Vercel → Project → Settings → Environment Variables, then Redeploy)

| Name | What it does |
|---|---|
| `NEXT_PUBLIC_WHATSAPP` | Your WhatsApp number. Shows the WhatsApp buttons and the "Send my order on WhatsApp" button. |
| `NEXT_PUBLIC_SITE_URL` | Your final address, e.g. `https://riveto.pk`, once you connect your own domain. Without it, the Vercel address is used. |
| `ORDER_WEBHOOK_URL` | Where each new order is sent as JSON (Google Sheet, Zapier, Make, Slack...). |
| `GOOGLE_SITE_VERIFICATION` | The code Google Search Console gives you, to prove the site is yours. |

`NEXT_PUBLIC_` values are built into the pages, so **Redeploy** after changing them.

## Where orders go

1. **Vercel logs** (always on): Project → **Logs**, search for `NEW ORDER`.
2. **Your WhatsApp:** after ordering, the customer taps **Send my order on WhatsApp** and the full order arrives in your chat.
3. **Google Sheet** (recommended, free):
   1. Create a Google Sheet. Open **Extensions → Apps Script**, replace the code with the script below and **Save**.
   2. **Deploy → New deployment → Web app**. *Execute as:* Me. *Who has access:* Anyone. Copy the Web app URL.
   3. Add it in Vercel as `ORDER_WEBHOOK_URL` and Redeploy.

```js
function doPost(e) {
  const o = JSON.parse(e.postData.contents);
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  if (sheet.getLastRow() === 0) sheet.appendRow(["Date", "Order", "Name", "Phone", "City", "Address", "Items", "Delivery", "Total", "Note"]);
  sheet.appendRow([
    new Date(o.createdAt), o.id, o.customer.name, "'" + o.customer.phone, o.customer.city, o.customer.address,
    o.lines.map((l) => `${l.name} ${l.colour} ${l.size} x${l.qty}`).join("\n"), o.shipping, o.total, o.customer.note,
  ]);
  return ContentService.createTextOutput("ok");
}
```

## Change products

Products live in `data/products.csv`, the same WooCommerce export format as before.

1. Edit `data/products.csv` (Excel or Google Sheets, saved as CSV). To use real photos, add an **Images** column with one or more image links separated by commas.
2. Run `npm run import-products`. This rewrites `data/products.json` and `data/cart.json`.
3. Upload the three changed files to GitHub. Vercel rebuilds the site.

Photos: 4:5 shape (e.g. 1200 × 1500), under 200 KB each. If they are hosted on another website, add that host to `images.remotePatterns` in `next.config.ts`.

Stock numbers come from the CSV. Orders do not lower them automatically, so update the CSV as you sell.

## Change text and the home page

- Store name, slogan, announcement bar, delivery time and shipping charges: `lib/site.ts`
- Banner slides (text, links, photos): `lib/home.ts`
- FAQ and policy pages: `lib/pages.ts`
- Colours and fonts: the top of `app/globals.css`

## After launch: tell Google

1. Open search.google.com/search-console, add your site address, and choose the **HTML tag** method. Copy the code inside `content="..."` into `GOOGLE_SITE_VERIFICATION` and Redeploy, then click **Verify**.
2. In Search Console, open **Sitemaps** and submit `sitemap.xml`.
3. Check your product pages in Google's Rich Results Test: search.google.com/test/rich-results

## Run it on your computer (optional)

Needs Node.js 20.9 or newer.

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # production build, same as Vercel
```
