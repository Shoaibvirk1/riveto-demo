/* Riveto theme: small, dependency-free, loaded with defer. */
(function () {
	"use strict";

	/* ---------- Search: slides open over a dimmed page, with live suggestions ---------- */
	var bar = document.getElementById("searchBar");
	var scrim = document.querySelector(".search-scrim");
	// Keep the dim layer outside the header so the header stays bright above it.
	if (scrim && scrim.parentNode !== document.body) document.body.appendChild(scrim);
	var toggles = document.querySelectorAll("[data-search-toggle]");
	var results = document.querySelector("[data-search-results]");
	var input = bar ? bar.querySelector("input[type=search]") : null;
	var closeTimer = null, typeTimer = null, lastQ = "";
	var R = window.RIVETO || {};
	function setExpanded(v) { toggles.forEach(function (t) { t.setAttribute("aria-expanded", v ? "true" : "false"); }); }
	function openSearch() {
		if (!bar) return;
		clearTimeout(closeTimer);
		bar.hidden = false; if (scrim) scrim.hidden = false;
		document.body.classList.add("searching");
		requestAnimationFrame(function () { requestAnimationFrame(function () { bar.classList.add("open"); if (scrim) scrim.classList.add("open"); }); });
		setExpanded(true);
		setTimeout(function () { if (input) input.focus(); }, 60);
	}
	function closeSearch(returnFocus) {
		if (!bar || bar.hidden) return;
		bar.classList.remove("open"); if (scrim) scrim.classList.remove("open");
		document.body.classList.remove("searching");
		setExpanded(false);
		closeTimer = setTimeout(function () { bar.hidden = true; if (scrim) scrim.hidden = true; }, 220);
		if (returnFocus) {
			var visible = Array.prototype.filter.call(toggles, function (t) { return t.offsetParent !== null; })[0];
			if (visible) visible.focus();
		}
	}
	toggles.forEach(function (t) {
		t.addEventListener("click", function () { if (bar.hidden || !bar.classList.contains("open")) openSearch(); else closeSearch(true); });
	});
	document.querySelectorAll("[data-search-close]").forEach(function (b) { b.addEventListener("click", function () { closeSearch(true); }); });
	document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeSearch(true); });

	function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }
	function mark(name, q) {
		var i = name.toLowerCase().indexOf(q.toLowerCase());
		if (i < 0) return esc(name);
		return esc(name.slice(0, i)) + "<mark>" + esc(name.slice(i, i + q.length)) + "</mark>" + esc(name.slice(i + q.length));
	}
	function money(p) {
		if (!p || !p.prices) return "";
		var minor = p.prices.currency_minor_unit || 0;
		var v = parseInt(p.prices.price, 10) / Math.pow(10, minor);
		return (p.prices.currency_prefix || "") + v.toLocaleString("en-PK") + (p.prices.currency_suffix || "");
	}
	function suggest(q) {
		if (!results || !R.searchApi) return;
		q = (q || "").trim(); lastQ = q;
		if (q.length < 2) { results.hidden = true; results.innerHTML = ""; return; }
		fetch(R.searchApi + (R.searchApi.indexOf("?") > -1 ? "&" : "?") + "per_page=5&search=" + encodeURIComponent(q), { credentials: "same-origin" })
			.then(function (r) { return r.ok ? r.json() : []; })
			.then(function (list) {
				if (q !== lastQ) return;
				var action = bar.querySelector("form").getAttribute("action");
				var all = action + (action.indexOf("?") > -1 ? "&" : "?") + "post_type=product&s=" + encodeURIComponent(q);
				if (!list.length) { results.innerHTML = '<p class="sb-none">' + esc((R.i18n || {}).none) + "</p>"; results.hidden = false; return; }
				results.innerHTML = list.map(function (p) {
					var slugs = (p.categories || []).map(function (c) { return c.slug; }).join(" ");
					var art = /women/.test(slugs) ? "hero-1-1" : /cargo/.test(slugs) ? "hero-2-1" : /chino/.test(slugs) ? "hero-3-1" : "hero-1-2";
					var img = p.images && p.images[0] ? '<img src="' + esc(p.images[0].thumbnail || p.images[0].src) + '" alt="" loading="lazy">'
						: (window.RIVETO && window.RIVETO.artBase ? '<img class="sb-art" src="' + esc(window.RIVETO.artBase + art + ".svg") + '" alt="" loading="lazy">' : "");
					var cat = p.categories && p.categories[0] ? p.categories[0].name : "";
					var so = p.is_in_stock === false ? " · " + esc((R.i18n || {}).soldOut) : "";
					return '<a class="sb-item" role="option" href="' + esc(p.permalink) + '"><span class="sb-th">' + img + '</span><span class="sb-tx"><b>' + mark(p.name, q) + "</b><small>" + esc(cat) + so + '</small></span><span class="sb-pr">' + esc(money(p)) + "</span></a>";
				}).join("") + '<a class="sb-all" href="' + esc(all) + '">' + esc((R.i18n || {}).all) + " “" + esc(q) + "”</a>";
				results.hidden = false;
			})
			.catch(function () {});
	}
	if (input) {
		input.addEventListener("input", function () { clearTimeout(typeTimer); var v = input.value; typeTimer = setTimeout(function () { suggest(v); }, 220); });
		bar.addEventListener("keydown", function (e) {
			if (!results || results.hidden || (e.key !== "ArrowDown" && e.key !== "ArrowUp")) return;
			var items = [].slice.call(results.querySelectorAll("a")); if (!items.length) return;
			var i = items.indexOf(document.activeElement); e.preventDefault();
			i = e.key === "ArrowDown" ? Math.min(items.length - 1, i + 1) : i - 1;
			if (i < 0) input.focus(); else items[i].focus();
		});
	}

	/* ---------- Banner slider ---------- */
	document.querySelectorAll("[data-slider]").forEach(function (el) {
		var track = el.querySelector(".ctrack");
		var slides = el.querySelectorAll(".cslide");
		var dots = el.querySelectorAll(".cdot");
		var n = slides.length, i = 0, paused = false, timer = null;
		if (n < 2 || !track) return;
		var secs = parseInt(el.getAttribute("data-seconds") || "5", 10);
		var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

		function go(k) {
			i = (k + n) % n;
			track.style.transform = "translateX(" + (-100 * i) + "%)";
			slides.forEach(function (s, j) {
				if (j === i) { s.removeAttribute("aria-hidden"); s.removeAttribute("inert"); }
				else { s.setAttribute("aria-hidden", "true"); s.setAttribute("inert", ""); }
			});
			dots.forEach(function (d, j) {
				if (j === i) d.setAttribute("aria-current", "true"); else d.removeAttribute("aria-current");
			});
			// Lazy slide images start loading just before they are needed.
			var next = slides[(i + 1) % n];
			next.querySelectorAll("img[loading=lazy]").forEach(function (img) { img.loading = "eager"; });
		}
		function start() {
			if (reduce || secs <= 0) return;
			clearInterval(timer);
			timer = setInterval(function () { if (!paused && !document.hidden) go(i + 1); }, secs * 1000);
		}
		el.addEventListener("click", function (e) {
			var b = e.target.closest(".cnav, .cdot");
			if (!b) return;
			if (b.classList.contains("cdot")) go(parseInt(b.getAttribute("data-go"), 10));
			else go(i + parseInt(b.getAttribute("data-dir"), 10));
			start();
		});
		el.addEventListener("mouseenter", function () { paused = true; });
		el.addEventListener("mouseleave", function () { paused = false; });
		el.addEventListener("focusin", function () { paused = true; });
		el.addEventListener("focusout", function () { paused = false; });
		var x0 = null;
		el.addEventListener("touchstart", function (e) { x0 = e.touches[0].clientX; paused = true; }, { passive: true });
		el.addEventListener("touchend", function (e) {
			if (x0 === null) return;
			var dx = e.changedTouches[0].clientX - x0;
			x0 = null; paused = false;
			if (Math.abs(dx) > 40) { go(i + (dx < 0 ? 1 : -1)); start(); }
		});
		start();
	});

	/* ---------- Cart count ----------
	   Pages are cached and identical for everyone, so the count is fetched here, and only when
	   WooCommerce's cookie says this visitor has something in the cart. */
	var badge = document.querySelector("[data-cart-count]");
	function showCount(c) {
		if (!badge) return;
		badge.textContent = c;
		badge.hidden = !c;
		var btn = badge.closest("a");
		if (btn) btn.setAttribute("aria-label", "Cart, " + c + " item" + (c === 1 ? "" : "s"));
	}
	function refreshCount() {
		if (!badge || !window.RIVETO || !window.RIVETO.cartApi) return;
		if (document.cookie.indexOf("woocommerce_items_in_cart=1") === -1) { showCount(0); return; }
		fetch(window.RIVETO.cartApi, { credentials: "same-origin" })
			.then(function (r) { return r.ok ? r.json() : null; })
			.then(function (d) { if (d && typeof d.items_count === "number") showCount(d.items_count); })
			.catch(function () {});
	}
	refreshCount();
	document.body.addEventListener("added_to_cart", refreshCount);
	if (window.jQuery) window.jQuery(document.body).on("added_to_cart removed_from_cart updated_cart_totals", refreshCount);
	window.addEventListener("pageshow", function (e) { if (e.persisted) refreshCount(); });

	/* ---------- Mark the current menu item on shop links with query strings ---------- */
	var here = location.pathname + location.search;
	document.querySelectorAll(".cats a, .cats-m a").forEach(function (a) {
		try {
			var u = new URL(a.href, location.href);
			if (u.pathname + u.search === here) a.setAttribute("aria-current", "page");
		} catch (err) {}
	});
})();


/* ---------- Filter dropdowns: one open at a time, close on outside click or Escape ---------- */
(function () {
	"use strict";
	var drops = document.querySelectorAll(".fdrop");
	if (!drops.length) return;
	drops.forEach(function (d) {
		d.addEventListener("toggle", function () {
			if (d.open) drops.forEach(function (o) { if (o !== d) o.open = false; });
		});
	});
	document.addEventListener("click", function (e) {
		if (!e.target.closest(".fdrop")) drops.forEach(function (d) { d.open = false; });
	});
	document.addEventListener("keydown", function (e) {
		if (e.key !== "Escape") return;
		drops.forEach(function (d) { if (d.open) { d.open = false; d.querySelector("summary").focus(); } });
	});
})();

/* ---------- Quantity: big − / + buttons around the number ---------- */
(function () {
	"use strict";
	function enhance(root) {
		(root || document).querySelectorAll(".quantity:not(.rv-qty)").forEach(function (q) {
			var input = q.querySelector("input.qty");
			if (!input || input.type === "hidden") return;
			q.classList.add("rv-qty");
			function btn(label, delta) {
				var b = document.createElement("button");
				b.type = "button";
				b.className = "qty-btn";
				b.setAttribute("aria-label", label);
				b.textContent = delta < 0 ? "−" : "+";
				b.addEventListener("click", function () {
					var step = parseFloat(input.step) || 1;
					var min = input.min !== "" ? parseFloat(input.min) : 0;
					var max = input.max !== "" ? parseFloat(input.max) : Infinity;
					var v = (parseFloat(input.value) || 0) + delta * step;
					v = Math.max(min, Math.min(max, v));
					input.value = v;
					input.dispatchEvent(new Event("change", { bubbles: true }));
					if (window.jQuery) window.jQuery(input).trigger("change");
				});
				return b;
			}
			input.parentNode.insertBefore(btn("Decrease quantity", -1), input);
			input.parentNode.insertBefore(btn("Increase quantity", 1), input.nextSibling);
		});
	}
	enhance();
	if (window.jQuery) window.jQuery(document.body).on("updated_cart_totals updated_wc_div", function () { enhance(); });
})();
