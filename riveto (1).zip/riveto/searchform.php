<?php
/**
 * Search form (products first).
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;
$rv_id = wp_unique_id( 'rv-s-' );
?>
<form class="search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label for="<?php echo esc_attr( $rv_id ); ?>" class="sr"><?php esc_html_e( 'Search products', 'riveto' ); ?></label>
	<input id="<?php echo esc_attr( $rv_id ); ?>" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Search products', 'riveto' ); ?>">
	<?php if ( riveto_wc() ) : ?>
		<input type="hidden" name="post_type" value="product">
	<?php endif; ?>
	<button class="btn" type="submit"><?php esc_html_e( 'Search', 'riveto' ); ?></button>
</form>
