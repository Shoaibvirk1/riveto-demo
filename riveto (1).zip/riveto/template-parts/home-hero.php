<?php
/**
 * Full-width banner slider.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

$slides = array();
for ( $i = 1; $i <= 4; $i++ ) {
	$title = trim( (string) riveto_mod( "hero_{$i}_title" ) );
	if ( '' === $title ) {
		continue;
	}
	$slides[] = array(
		'n'      => $i,
		'title'  => $title,
		'text'   => riveto_mod( "hero_{$i}_text" ),
		'button' => riveto_mod( "hero_{$i}_button" ),
		'link'   => riveto_link( riveto_mod( "hero_{$i}_link" ) ),
		'image'  => (int) get_theme_mod( "riveto_hero_{$i}_image", 0 ),
	);
}
if ( ! $slides ) {
	return;
}
$count   = count( $slides );
$seconds = (int) riveto_mod( 'hero_seconds' );
$scenes  = array( 1 => 'hs-denim', 2 => 'hs-cargo', 3 => 'hs-chino', 4 => 'hs-sale' );

$GLOBALS['riveto_first_hero'] = true;
?>
<section class="hero2" data-slider data-seconds="<?php echo esc_attr( $seconds ); ?>" aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured collections', 'riveto' ); ?>">
	<div class="cview">
		<div class="ctrack">
			<?php foreach ( $slides as $k => $s ) : ?>
				<div class="cslide hs <?php echo esc_attr( $s['image'] ? 'hs-hasphoto' : $scenes[ $s['n'] ] ); ?>" role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr( sprintf( '%d / %d', $k + 1, $count ) ); ?>" <?php echo $k ? 'aria-hidden="true" inert' : ''; ?>>
					<?php
					if ( $s['image'] ) {
						echo wp_get_attachment_image( $s['image'], 'riveto-hero', false, array( 'class' => 'hs-photo', 'alt' => '', 'sizes' => '100vw' ) );
					}
					?>
					<div class="wrap hs-in">
						<div class="hs-copy">
							<?php if ( 0 === $k ) : ?>
								<h1><?php echo esc_html( $s['title'] ); ?></h1>
							<?php else : ?>
								<h2 class="hs-h"><?php echo esc_html( $s['title'] ); ?></h2>
							<?php endif; ?>
							<?php if ( $s['text'] ) : ?>
								<p><?php echo esc_html( $s['text'] ); ?></p>
							<?php endif; ?>
							<div class="hero-cta">
								<?php if ( $s['button'] ) : ?>
									<a class="btn hs-btn" href="<?php echo esc_url( $s['link'] ); ?>"><?php echo esc_html( $s['button'] ); ?></a>
								<?php endif; ?>
								<a class="btn hs-ghost" href="<?php echo esc_url( riveto_shop_url() ); ?>"><?php esc_html_e( 'Explore all styles', 'riveto' ); ?></a>
							</div>
						</div>
						<?php if ( ! $s['image'] ) : ?>
							<div class="hs-art" aria-hidden="true">
								<?php for ( $f = 1; $f <= 3; $f++ ) : ?>
									<img class="hs-fan hf<?php echo (int) $f; ?>" src="<?php echo esc_url( RIVETO_URI . '/assets/img/hero-' . $s['n'] . '-' . $f . '.svg' ); ?>" alt="" width="216" height="468" <?php echo 0 === $k ? 'fetchpriority="high"' : 'loading="lazy"'; ?> decoding="async">
								<?php endfor; ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php if ( $count > 1 ) : ?>
		<button type="button" class="cnav hs-prev" data-dir="-1" aria-label="<?php esc_attr_e( 'Previous slide', 'riveto' ); ?>"><?php echo riveto_icon( 'left', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
		<button type="button" class="cnav hs-next" data-dir="1" aria-label="<?php esc_attr_e( 'Next slide', 'riveto' ); ?>"><?php echo riveto_icon( 'right', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
		<div class="cdots hs-dots">
			<?php for ( $d = 0; $d < $count; $d++ ) : ?>
				<button type="button" class="cdot" data-go="<?php echo (int) $d; ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: slide number */ __( 'Show slide %d', 'riveto' ), $d + 1 ) ); ?>" <?php echo 0 === $d ? 'aria-current="true"' : ''; ?>></button>
			<?php endfor; ?>
		</div>
	<?php endif; ?>
</section>
