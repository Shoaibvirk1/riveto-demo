<?php
/**
 * "Trending this week": Featured products in a bento grid.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

$products = riveto_trending_products( 6 );
if ( count( $products ) < 3 ) {
	return;
}
$products = array_slice( $products, 0, count( $products ) >= 6 ? 6 : 3 );
$scenes   = array( 'sc-street', 'sc-shutter', 'sc-studio', 'sc-gallery', 'sc-sky', 'sc-white' );
?>
<section class="wrap sec look">
	<div class="sec-h"><h2><?php esc_html_e( 'Trending this week', 'riveto' ); ?></h2><a href="<?php echo esc_url( riveto_shop_url() ); ?>"><?php esc_html_e( 'See all styles', 'riveto' ); ?></a></div>
	<div class="bento bento-<?php echo (int) count( $products ); ?>">
		<?php
		foreach ( $products as $n => $product ) :
			$has_photo = (bool) $product->get_image_id();
			$created   = $product->get_date_created();
			$is_new    = $created && ( time() - $created->getTimestamp() ) < 30 * DAY_IN_SECONDS;
			$tag       = $product->is_on_sale() ? __( 'Sale', 'riveto' ) : ( $is_new ? __( 'New', 'riveto' ) : '' );
			?>
			<a class="m-item" href="<?php echo esc_url( $product->get_permalink() ); ?>">
				<span class="m-pic <?php echo $has_photo ? '' : esc_attr( 'm-scene ' . $scenes[ $n % 6 ] ); ?>"><?php echo riveto_product_image( $product, 'riveto-card', $n ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<?php if ( $tag ) : ?>
					<span class="m-badge <?php echo $product->is_on_sale() ? 'sale' : ''; ?>"><?php echo esc_html( $tag ); ?></span>
				<?php endif; ?>
				<span class="m-cap"><b><?php echo esc_html( $product->get_name() ); ?></b><span><?php echo wp_kses_post( $product->get_price_html() ); ?></span></span>
				<span class="m-go" aria-hidden="true"><?php echo riveto_icon( 'arrow', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			</a>
		<?php endforeach; ?>
	</div>
</section>
