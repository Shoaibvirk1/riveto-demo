<?php
/**
 * "Shop by category": top-level product categories with their photo.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

$cats = get_terms(
	array(
		'taxonomy'   => 'product_cat',
		'parent'     => 0,
		'hide_empty' => true,
		'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
		'number'     => 8,
		'orderby'    => 'menu_order',
	)
);
if ( is_wp_error( $cats ) || ! $cats ) {
	return;
}
$cats = array_slice( riveto_sort_cats( $cats ), 0, 4 );
$scenes = array( 'men', 'women', 'cargo', 'chinos' );
?>
<section class="wrap sec">
	<div class="sec-h"><h2><?php esc_html_e( 'Shop by category', 'riveto' ); ?></h2></div>
	<div class="tiles">
		<?php
		foreach ( $cats as $i => $cat ) :
			$thumb = (int) get_term_meta( $cat->term_id, 'thumbnail_id', true );
			$scene = $scenes[ $i % 4 ];
			foreach ( array( 'women', 'men', 'cargo', 'chino' ) as $key ) {
				if ( false !== strpos( $cat->slug, $key ) ) {
					$scene = 'chino' === $key ? 'chinos' : $key;
					break;
				}
			}
			?>
			<a class="tile" href="<?php echo esc_url( get_term_link( $cat ) ); ?>">
				<span class="ph <?php echo $thumb ? '' : esc_attr( 'tile-scene scene-' . $scene ); ?>" <?php echo $thumb ? '' : 'style="background-image:url(' . esc_url( RIVETO_URI . '/assets/img/scene-' . $scene . '.webp' ) . ')"'; ?>>
					<?php
					if ( $thumb ) {
						echo wp_get_attachment_image( $thumb, 'riveto-card', false, array( 'alt' => $cat->name, 'class' => 'rv-img' ) );
					} else {
						printf( '<img class="rv-art" src="%s" alt="" width="216" height="468" loading="lazy" decoding="async">', esc_url( RIVETO_URI . '/assets/img/cat-' . $scene . '.svg' ) );
					}
					?>
				</span>
				<b><?php echo esc_html( $cat->name ); ?></b>
				<small>
				<?php
				/* translators: %s: number of products */
				echo esc_html( sprintf( _n( '%s style', '%s styles', $cat->count, 'riveto' ), number_format_i18n( $cat->count ) ) );
				?>
				</small>
			</a>
		<?php endforeach; ?>
	</div>
</section>
