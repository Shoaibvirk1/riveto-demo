<?php
/**
 * "In their own words": the latest real 4 and 5-star product reviews. Hidden until there are some.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

$reviews = riveto_latest_reviews( 3 );
if ( ! $reviews ) {
	return;
}
?>
<section class="reviews-band">
	<div class="wrap sec">
		<div class="sec-h"><h2><?php esc_html_e( 'Customer reviews', 'riveto' ); ?></h2></div>
		<div class="quotes">
			<?php
			foreach ( $reviews as $r ) :
				$rating  = (int) get_comment_meta( $r->comment_ID, 'rating', true );
				$product = wc_get_product( $r->comment_post_ID );
				?>
				<figure class="quote">
					<span class="stars" role="img" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: rating */ __( 'Rated %d out of 5', 'riveto' ), $rating ) ); ?>"><?php echo esc_html( str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating ) ); ?></span>
					<blockquote><p><?php echo esc_html( wp_trim_words( $r->comment_content, 30 ) ); ?></p></blockquote>
					<figcaption class="who">
						<?php echo esc_html( $r->comment_author ); ?>
						<?php if ( $product ) : ?>
							· <a href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo esc_html( $product->get_name() ); ?></a>
						<?php endif; ?>
					</figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
	</div>
</section>
