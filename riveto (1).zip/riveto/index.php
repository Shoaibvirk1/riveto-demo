<?php
/**
 * Fallback template: blog, search results and anything without its own template.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" class="wrap page-main" tabindex="-1">
	<header class="page-head">
		<h1>
			<?php
			if ( is_search() ) {
				/* translators: %s: search term */
				printf( esc_html__( 'Results for “%s”', 'riveto' ), esc_html( get_search_query() ) );
			} elseif ( is_archive() ) {
				echo wp_kses_post( get_the_archive_title() );
			} elseif ( is_home() && ! is_front_page() ) {
				single_post_title();
			} else {
				bloginfo( 'name' );
			}
			?>
		</h1>
	</header>
	<?php if ( have_posts() ) : ?>
		<div class="post-list">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<div class="muted"><?php the_excerpt(); ?></div>
				</article>
			<?php endwhile; ?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'Nothing found. Try another search or browse the shop.', 'riveto' ); ?></p>
		<a class="btn" href="<?php echo esc_url( riveto_shop_url() ); ?>"><?php esc_html_e( 'Go to the shop', 'riveto' ); ?></a>
	<?php endif; ?>
</main>
<?php
get_footer();
