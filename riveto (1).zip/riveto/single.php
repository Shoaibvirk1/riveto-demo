<?php
/**
 * Single blog post.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" class="wrap page-main prose" tabindex="-1">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<h1 class="page-title"><?php the_title(); ?></h1>
			<p class="muted small"><?php echo esc_html( get_the_date() ); ?></p>
			<?php
			if ( has_post_thumbnail() ) {
				the_post_thumbnail( 'large' );
			}
			?>
			<div class="entry"><?php the_content(); ?></div>
		</article>
	<?php endwhile; ?>
</main>
<?php
get_footer();
