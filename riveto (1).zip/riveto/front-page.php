<?php
/**
 * Home page. Every section can be edited or switched off in Appearance > Customize > Riveto home.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" tabindex="-1">
	<?php
	get_template_part( 'template-parts/home', 'hero' );

	if ( riveto_wc() ) {
		if ( riveto_mod( 'show_trending' ) ) {
			get_template_part( 'template-parts/home', 'trending' );
		}
		if ( riveto_mod( 'show_cats' ) ) {
			get_template_part( 'template-parts/home', 'categories' );
		}
	}

	if ( riveto_mod( 'show_slogan' ) ) :
		?>
		<section class="slogan" aria-label="<?php esc_attr_e( 'Our promise', 'riveto' ); ?>">
			<div class="wrap slogan-in">
				<p class="slogan-big"><?php echo esc_html( riveto_mod( 'slogan_big' ) ); ?></p>
				<p class="slogan-sub"><?php echo esc_html( riveto_mod( 'slogan_text' ) ); ?></p>
				<a class="btn slogan-btn" href="<?php echo esc_url( riveto_shop_url() ); ?>"><?php echo esc_html( riveto_mod( 'slogan_button' ) ); ?></a>
			</div>
		</section>
		<?php
	endif;

	if ( riveto_wc() && riveto_mod( 'show_best' ) ) :
		?>
		<section class="wrap sec">
			<div class="sec-h"><h2><?php esc_html_e( 'Best-sellers', 'riveto' ); ?></h2><a href="<?php echo esc_url( add_query_arg( 'orderby', 'popularity', riveto_shop_url() ) ); ?>"><?php esc_html_e( 'View all', 'riveto' ); ?></a></div>
			<?php echo do_shortcode( '[products limit="4" columns="4" best_selling="true"]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>
		<?php
	endif;

	if ( riveto_mod( 'show_trust' ) ) :
		$wa = riveto_whatsapp_display();
		?>
		<section class="trustband" aria-label="<?php esc_attr_e( 'Shopping with us', 'riveto' ); ?>">
			<ul class="wrap trust">
				<li><?php echo riveto_icon( 'cash' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><b><?php esc_html_e( 'Cash on Delivery', 'riveto' ); ?></b><small><?php esc_html_e( 'Pay when your parcel arrives', 'riveto' ); ?></small></span></li>
				<li><?php echo riveto_icon( 'truck' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><b><?php echo esc_html( riveto_storekit( 'delivery_time', __( 'Delivered in 3-5 working days', 'riveto' ) ) ); ?></b><small><?php esc_html_e( 'Anywhere in Pakistan', 'riveto' ); ?></small></span></li>
				<li><?php echo riveto_icon( 'swap' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><b><?php echo esc_html( riveto_storekit( 'exchange_text', __( '7-day size exchange', 'riveto' ) ) ); ?></b><small><?php esc_html_e( 'Easy, no questions', 'riveto' ); ?></small></span></li>
				<?php if ( $wa ) : ?>
					<li><?php echo riveto_icon( 'chat' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><b><?php esc_html_e( 'WhatsApp us', 'riveto' ); ?></b><small><a href="<?php echo esc_url( riveto_whatsapp_link() ); ?>" rel="noopener" target="_blank"><?php echo esc_html( $wa ); ?></a></small></span></li>
				<?php endif; ?>
			</ul>
		</section>
		<?php
	endif;

	if ( riveto_wc() && riveto_mod( 'show_new' ) ) :
		?>
		<section class="wrap sec">
			<div class="sec-h"><h2><?php esc_html_e( 'New arrivals', 'riveto' ); ?></h2><a href="<?php echo esc_url( add_query_arg( 'orderby', 'date', riveto_shop_url() ) ); ?>"><?php esc_html_e( 'View all', 'riveto' ); ?></a></div>
			<?php echo do_shortcode( '[products limit="4" columns="4" orderby="date" order="DESC"]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</section>
		<?php
	endif;

	if ( riveto_wc() && riveto_mod( 'show_soldout' ) ) {
		$sold_out = wc_get_products(
			array(
				'status'       => 'publish',
				'stock_status' => 'outofstock',
				'limit'        => 4,
				'return'       => 'ids',
				'orderby'      => 'date',
				'order'        => 'DESC',
			)
		);
		if ( $sold_out ) :
			?>
			<section class="wrap sec soldout-sec">
				<div class="sec-h"><div><h2><?php esc_html_e( 'Sold out, back soon', 'riveto' ); ?></h2><p class="muted"><?php esc_html_e( 'These went fast. Message us on WhatsApp and we will tell you when they are back.', 'riveto' ); ?></p></div><a href="<?php echo esc_url( add_query_arg( 'stock', 'out', riveto_shop_url() ) ); ?>"><?php esc_html_e( 'See all', 'riveto' ); ?></a></div>
				<?php echo do_shortcode( '[products limit="4" columns="4" ids="' . esc_attr( implode( ',', array_map( 'absint', $sold_out ) ) ) . '"]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</section>
			<?php
		endif;
	}

	if ( riveto_wc() && riveto_mod( 'show_reviews' ) ) {
		get_template_part( 'template-parts/home', 'reviews' );
	}
	?>
</main>
<?php
get_footer();
