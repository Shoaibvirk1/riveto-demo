<?php
/**
 * Site header.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#15171C">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php esc_html_e( 'Skip to content', 'riveto' ); ?></a>

<header class="site-header">
	<div class="wrap hdr">
		<div class="hdr-logo">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php echo esc_html( strtolower( get_bloginfo( 'name' ) ) ); ?><span>.</span></a>
			<?php endif; ?>
		</div>

		<nav class="cats" aria-label="<?php esc_attr_e( 'Main menu', 'riveto' ); ?>">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'depth'          => 1,
					)
				);
			} else {
				riveto_menu_fallback();
			}
			?>
		</nav>

		<div class="hdr-actions">
			<button class="search-pill" type="button" data-search-toggle aria-controls="searchBar" aria-expanded="false">
				<?php echo riveto_icon( 'search', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span><?php esc_html_e( 'Search', 'riveto' ); ?></span>
			</button>
			<button class="icon-btn search-ic" type="button" data-search-toggle aria-controls="searchBar" aria-expanded="false" aria-label="<?php esc_attr_e( 'Search', 'riveto' ); ?>">
				<?php echo riveto_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</button>
			<?php if ( riveto_wc() ) : ?>
				<a class="icon-btn" href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" aria-label="<?php esc_attr_e( 'My account', 'riveto' ); ?>">
					<?php echo riveto_icon( 'user' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</a>
				<a class="icon-btn cart-btn" href="<?php echo esc_url( wc_get_cart_url() ); ?>" aria-label="<?php esc_attr_e( 'Cart', 'riveto' ); ?>">
					<?php echo riveto_icon( 'bag' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span class="count" data-cart-count hidden>0</span>
				</a>
			<?php endif; ?>
		</div>
	</div>

	<div class="search-scrim" data-search-close hidden></div>
	<div class="searchbar" id="searchBar" hidden>
		<div class="wrap">
			<form class="search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<label for="rv-q" class="sr"><?php esc_html_e( 'Search products', 'riveto' ); ?></label>
				<input id="rv-q" type="search" name="s" placeholder="<?php esc_attr_e( 'Try slim, cargo or black', 'riveto' ); ?>" autocomplete="off" value="<?php echo esc_attr( get_search_query() ); ?>">
				<?php if ( riveto_wc() ) : ?>
					<input type="hidden" name="post_type" value="product">
				<?php endif; ?>
				<button class="btn" type="submit"><?php esc_html_e( 'Search', 'riveto' ); ?></button>
				<button class="icon-x" type="button" data-search-close aria-label="<?php esc_attr_e( 'Close search', 'riveto' ); ?>"><?php echo riveto_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			</form>
			<div class="sb-results" data-search-results role="listbox" aria-label="<?php esc_attr_e( 'Suggestions', 'riveto' ); ?>" hidden></div>
		</div>
	</div>

	<nav class="cats-m" aria-label="<?php esc_attr_e( 'Main menu', 'riveto' ); ?>">
		<?php
		if ( has_nav_menu( 'primary' ) ) {
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'depth'          => 1,
				)
			);
		} else {
			riveto_menu_fallback();
		}
		?>
	</nav>
</header>
