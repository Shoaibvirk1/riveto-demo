<?php
/**
 * Pages: About, FAQ, policies, cart, checkout and my account.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

get_header();
$is_shop_page = function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() );
?>
<main id="main" class="wrap page-main <?php echo $is_shop_page ? 'page-wc' : 'prose'; ?>" tabindex="-1">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<h1 class="page-title"><?php the_title(); ?></h1>
			<div class="entry"><?php the_content(); ?></div>
		</article>
	<?php endwhile; ?>
</main>
<?php
get_footer();
