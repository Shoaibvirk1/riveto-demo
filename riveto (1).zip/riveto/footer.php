<?php
/**
 * Site footer.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

$shop = riveto_shop_url();
?>
<footer class="site-footer">
	<div class="wrap">
		<div class="fcols">
			<div class="fbrand">
				<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( strtolower( get_bloginfo( 'name' ) ) ); ?><span>.</span></a>
				<p class="f-slogan"><?php echo esc_html( riveto_mod( 'slogan_big' ) ); ?></p>
				<p class="muted"><?php echo esc_html( riveto_mod( 'footer_text' ) ); ?></p>
				<ul class="fbadges" aria-label="<?php esc_attr_e( 'Why shop with us', 'riveto' ); ?>">
					<li><?php echo riveto_icon( 'cash', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Cash on Delivery', 'riveto' ); ?></li>
					<li><?php echo riveto_icon( 'swap', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( '7-day exchange', 'riveto' ); ?></li>
					<li><?php echo riveto_icon( 'truck', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Nationwide delivery', 'riveto' ); ?></li>
				</ul>
			</div>
			<div>
				<h2 class="fh"><?php esc_html_e( 'Shop', 'riveto' ); ?></h2>
				<?php
				riveto_footer_menu(
					'footer-shop',
					array(
						array( add_query_arg( 'orderby', 'date', $shop ), __( 'New arrivals', 'riveto' ) ),
						array( add_query_arg( 'orderby', 'popularity', $shop ), __( 'Best-sellers', 'riveto' ) ),
						array( add_query_arg( 'on_sale', '1', $shop ), __( 'Sale', 'riveto' ) ),
						array( $shop, __( 'All styles', 'riveto' ) ),
					)
				);
				?>
			</div>
			<div>
				<h2 class="fh"><?php esc_html_e( 'Help', 'riveto' ); ?></h2>
				<?php
				$help = array();
				foreach ( array( 'contact' => __( 'Contact us', 'riveto' ), 'faq' => __( 'FAQ', 'riveto' ), 'about' => __( 'About us', 'riveto' ) ) as $slug => $label ) {
					$u = riveto_page_url( $slug );
					if ( $u ) {
						$help[] = array( $u, $label );
					}
				}
				if ( riveto_wc() ) {
					$help[] = array( wc_get_page_permalink( 'myaccount' ), __( 'My account', 'riveto' ) );
				}
				riveto_footer_menu( 'footer-help', $help );
				?>
			</div>
			<div>
				<h2 class="fh"><?php esc_html_e( 'Policies', 'riveto' ); ?></h2>
				<?php
				$pol = array();
				foreach ( array( 'shipping-policy' => __( 'Shipping policy', 'riveto' ), 'refund_returns' => __( 'Return and exchange', 'riveto' ), 'privacy-policy' => __( 'Privacy policy', 'riveto' ), 'terms' => __( 'Terms of service', 'riveto' ) ) as $slug => $label ) {
					$u = riveto_page_url( $slug );
					if ( $u ) {
						$pol[] = array( $u, $label );
					}
				}
				riveto_footer_menu( 'footer-policies', $pol );
				?>
			</div>
		</div>
		<?php if ( is_active_sidebar( 'footer-extra' ) ) : ?>
			<div class="footer-extra"><?php dynamic_sidebar( 'footer-extra' ); ?></div>
		<?php endif; ?>
		<div class="fbottom">
			<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'Prices in PKR.', 'riveto' ); ?></span>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
