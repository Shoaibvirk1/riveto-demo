<?php
/**
 * Product tabs shown as dropdowns (description open, the rest closed).
 *
 * Based on WooCommerce's single-product/tabs/tabs.php.
 *
 * @package Riveto
 * @version 9.8.0
 */

defined( 'ABSPATH' ) || exit;

$product_tabs = apply_filters( 'woocommerce_product_tabs', array() );

if ( ! empty( $product_tabs ) ) : ?>
	<div class="woocommerce-tabs wc-tabs-wrapper rv-acc">
		<?php
		$first = true;
		foreach ( $product_tabs as $key => $product_tab ) :
			$is_reviews = ( 'reviews' === $key );
			?>
			<details class="rv-acc-item woocommerce-Tabs-panel woocommerce-Tabs-panel--<?php echo esc_attr( $key ); ?>" id="tab-<?php echo esc_attr( $key ); ?>" <?php echo ( $first && ! $is_reviews ) ? 'open' : ''; ?>>
				<summary id="tab-title-<?php echo esc_attr( $key ); ?>">
					<span><?php echo wp_kses_post( apply_filters( 'woocommerce_product_' . $key . '_tab_title', $product_tab['title'], $key ) ); ?></span>
					<span class="chev" aria-hidden="true"></span>
				</summary>
				<div class="rv-acc-body">
					<?php
					if ( isset( $product_tab['callback'] ) ) {
						call_user_func( $product_tab['callback'], $key, $product_tab );
					}
					?>
				</div>
			</details>
			<?php
			$first = false;
		endforeach;
		?>
		<?php do_action( 'woocommerce_product_after_tabs' ); ?>
	</div>
<?php endif; ?>
