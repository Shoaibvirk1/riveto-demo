<?php
/**
 * Riveto theme bootstrap.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

define( 'RIVETO_VERSION', '1.0.1' );
define( 'RIVETO_DIR', get_template_directory() );
define( 'RIVETO_URI', get_template_directory_uri() );

require RIVETO_DIR . '/inc/helpers.php';
require RIVETO_DIR . '/inc/customizer.php';
require RIVETO_DIR . '/inc/performance.php';
require RIVETO_DIR . '/inc/seo.php';
require RIVETO_DIR . '/inc/woocommerce.php';
require RIVETO_DIR . '/inc/admin.php';

/**
 * Theme supports and menus.
 */
function riveto_setup() {
	load_theme_textdomain( 'riveto', RIVETO_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 80,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width' => 600,
			'single_image_width'    => 1000,
			'product_grid'          => array(
				'default_rows'    => 4,
				'min_rows'        => 1,
				'default_columns' => 4,
				'min_columns'     => 2,
				'max_columns'     => 4,
			),
		)
	);
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	register_nav_menus(
		array(
			'primary'         => __( 'Main menu (header)', 'riveto' ),
			'footer-shop'     => __( 'Footer: Shop', 'riveto' ),
			'footer-help'     => __( 'Footer: Help', 'riveto' ),
			'footer-policies' => __( 'Footer: Policies', 'riveto' ),
		)
	);

	// Crops used by the home page. Photos are 4:5, like the PRD asks.
	add_image_size( 'riveto-card', 600, 750, true );
	add_image_size( 'riveto-hero', 1920, 1080, false );
}
add_action( 'after_setup_theme', 'riveto_setup' );

/**
 * Styles and scripts. One CSS file, one small deferred JS file.
 */
function riveto_assets() {
	$css = RIVETO_DIR . '/assets/css/main.css';
	$js  = RIVETO_DIR . '/assets/js/main.js';

	wp_enqueue_style( 'riveto', RIVETO_URI . '/assets/css/main.css', array(), (string) filemtime( $css ) );

	wp_enqueue_script(
		'riveto',
		RIVETO_URI . '/assets/js/main.js',
		array(),
		(string) filemtime( $js ),
		array(
			'strategy'  => 'defer',
			'in_footer' => true,
		)
	);
	wp_localize_script(
		'riveto',
		'RIVETO',
		array(
			'cartApi'   => esc_url_raw( rest_url( 'wc/store/v1/cart' ) ),
			'artBase'   => esc_url_raw( RIVETO_URI . '/assets/img/' ),
			'searchApi' => esc_url_raw( rest_url( 'wc/store/v1/products' ) ),
			'i18n'      => array(
				'none'    => __( 'No products match. Try “slim”, “cargo” or “black”.', 'riveto' ),
				'all'     => __( 'See all results', 'riveto' ),
				'soldOut' => __( 'Sold out', 'riveto' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'riveto_assets' );

/**
 * Preload the two fonts used above the fold so text paints fast.
 */
function riveto_preload_fonts() {
	$fonts = array( 'figtree-latin-400-normal.woff2', 'bricolage-grotesque-latin-700-normal.woff2' );
	foreach ( $fonts as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( RIVETO_URI . '/assets/fonts/' . $font )
		);
	}
}
add_action( 'wp_head', 'riveto_preload_fonts', 1 );

/**
 * Font faces, printed inline so the font URLs follow the theme folder.
 */
function riveto_font_faces() {
	$base  = RIVETO_URI . '/assets/fonts/';
	$faces = array(
		array( 'Figtree', 400, 'figtree-latin-400-normal.woff2' ),
		array( 'Figtree', 500, 'figtree-latin-500-normal.woff2' ),
		array( 'Figtree', 600, 'figtree-latin-600-normal.woff2' ),
		array( 'Figtree', 700, 'figtree-latin-700-normal.woff2' ),
		array( 'Bricolage Grotesque', 500, 'bricolage-grotesque-latin-500-normal.woff2' ),
		array( 'Bricolage Grotesque', 700, 'bricolage-grotesque-latin-700-normal.woff2' ),
	);
	$css = '';
	foreach ( $faces as $f ) {
		$css .= sprintf(
			"@font-face{font-family:'%s';font-style:normal;font-weight:%d;font-display:swap;src:url('%s') format('woff2');}",
			$f[0],
			$f[1],
			esc_url( $base . $f[2] )
		);
	}
	wp_add_inline_style( 'riveto', $css );
}
add_action( 'wp_enqueue_scripts', 'riveto_font_faces', 20 );

/**
 * Footer widget area for anything extra the owner wants to add.
 */
function riveto_widgets() {
	register_sidebar(
		array(
			'name'          => __( 'Footer extra', 'riveto' ),
			'id'            => 'footer-extra',
			'description'   => __( 'Optional. Shows under the footer menus.', 'riveto' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
	register_sidebar(
		array(
			'name'          => __( 'Shop filters', 'riveto' ),
			'id'            => 'shop-filters',
			'description'   => __( 'Filters on the shop and category pages, each shown as a dropdown. Give every widget a title (for example "Waist size", "Colour", "Price").', 'riveto' ),
			'before_widget' => '<details id="%1$s" class="fgroup widget %2$s">',
			'after_widget'  => '</details>',
			'before_title'  => '<summary class="widget-title">',
			'after_title'   => '<span class="chev" aria-hidden="true"></span></summary>',
		)
	);
}
add_action( 'widgets_init', 'riveto_widgets' );


/**
 * On a fresh site WordPress drops its sample widgets (search, recent posts, archives...) into the
 * first widget area. Move them out of the footer and shop filters so the store starts clean.
 * Widgets the owner added themselves are left alone.
 */
function riveto_clean_default_widgets() {
	$sidebars = get_option( 'sidebars_widgets', array() );
	$blocks   = get_option( 'widget_block', array() );
	$changed  = false;
	foreach ( array( 'footer-extra', 'shop-filters' ) as $area ) {
		if ( empty( $sidebars[ $area ] ) || ! is_array( $sidebars[ $area ] ) ) {
			continue;
		}
		$all_default = true;
		foreach ( $sidebars[ $area ] as $wid ) {
			if ( 0 === strpos( $wid, 'block-' ) ) {
				$n       = (int) substr( $wid, 6 );
				$content = isset( $blocks[ $n ]['content'] ) ? $blocks[ $n ]['content'] : '';
				if ( ! preg_match( '/wp:(search|latest-posts|latest-comments|archives|categories)/', $content ) ) {
					$all_default = false;
				}
			} elseif ( ! preg_match( '/^(search|recent-posts|recent-comments|archives|categories|meta)-\d+$/', $wid ) ) {
				$all_default = false;
			}
		}
		if ( $all_default ) {
			$sidebars['wp_inactive_widgets'] = array_merge( isset( $sidebars['wp_inactive_widgets'] ) ? (array) $sidebars['wp_inactive_widgets'] : array(), $sidebars[ $area ] );
			$sidebars[ $area ]               = array();
			$changed                         = true;
		}
	}
	if ( $changed ) {
		update_option( 'sidebars_widgets', $sidebars );
	}
}
add_action( 'after_switch_theme', 'riveto_clean_default_widgets' );
