<?php
/**
 * WooCommerce integration.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

if ( ! riveto_wc() ) {
	return;
}

/* Theme wrappers instead of WooCommerce's defaults. */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

add_action(
	'woocommerce_before_main_content',
	function () {
		echo '<main id="main" class="wrap wc-main" tabindex="-1">';
	},
	10
);
add_action(
	'woocommerce_after_main_content',
	function () {
		echo '</main>';
	},
	10
);

/* Card button appears under the product on hover (always visible on phones). */
add_filter(
	'woocommerce_product_add_to_cart_text',
	function ( $text, $product ) {
		if ( ! $product->is_in_stock() ) {
			return __( 'Out of stock', 'riveto' );
		}
		return $product->is_type( 'variable' ) ? __( 'Choose size & add to cart', 'riveto' ) : __( 'Add to cart', 'riveto' );
	},
	10,
	2
);

add_filter(
	'woocommerce_sale_flash',
	function () {
		return '<span class="onsale">' . esc_html__( 'Sale', 'riveto' ) . '</span>';
	}
);

add_filter(
	'loop_shop_per_page',
	function () {
		return 16;
	}
);

add_filter(
	'woocommerce_output_related_products_args',
	function ( $args ) {
		$args['posts_per_page'] = 4;
		$args['columns']        = 4;
		return $args;
	}
);

/**
 * Current comma-separated values of a URL filter, e.g. filter_size=30,32.
 *
 * @param string $key Query key.
 * @return string[]
 */
function riveto_filter_values( $key ) {
	if ( empty( $_GET[ $key ] ) || ! is_string( $_GET[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return array();
	}
	return array_filter( array_map( 'sanitize_title', explode( ',', wp_unslash( $_GET[ $key ] ) ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
}

/**
 * URL with one value switched on or off in a comma-separated filter.
 *
 * @param string $key   Query key.
 * @param string $value Value.
 * @param bool   $multi Allow several values (sizes, colours) or just one (price, stock).
 * @return string
 */
function riveto_filter_url( $key, $value, $multi = true ) {
	$cur = riveto_filter_values( $key );
	if ( in_array( $value, $cur, true ) ) {
		$cur = array_diff( $cur, array( $value ) );
	} else {
		$cur = $multi ? array_merge( $cur, array( $value ) ) : array( $value );
	}
	$url = remove_query_arg( array( 'paged', 'product-page' ) );
	$url = preg_replace( '#/page/\d+/?#', '/', $url );
	if ( $cur ) {
		$url = add_query_arg( $key, implode( ',', $cur ), $url );
		if ( 0 === strpos( $key, 'filter_' ) ) {
			$url = add_query_arg( 'query_type_' . substr( $key, 7 ), 'or', $url );
		}
	} else {
		$url = remove_query_arg( array( $key, 'query_type_' . substr( $key, 7 ) ), $url );
	}
	return $url;
}

/**
 * One dropdown of filter options.
 *
 * @param string $label   Button label.
 * @param array  $options List of [value, label].
 * @param string $key     Query key.
 * @param bool   $multi   Several values allowed.
 */
function riveto_filter_dropdown( $label, $options, $key, $multi = true ) {
	if ( ! $options ) {
		return;
	}
	$cur   = riveto_filter_values( $key );
	$count = count( $cur );
	echo '<details class="fdrop' . ( $count ? ' is-active' : '' ) . '"><summary>' . esc_html( $label );
	if ( $count ) {
		echo ' <span class="fcount">' . (int) $count . '</span>';
	}
	echo '<span class="chev" aria-hidden="true"></span></summary><div class="fpanel" role="group" aria-label="' . esc_attr( $label ) . '">';
	foreach ( $options as $o ) {
		$on = in_array( (string) $o[0], $cur, true );
		printf(
			'<a class="fopt%s" href="%s" rel="nofollow" aria-pressed="%s"><span class="fbox" aria-hidden="true"></span>%s</a>',
			$on ? ' on' : '',
			esc_url( riveto_filter_url( $key, (string) $o[0], $multi ) ),
			$on ? 'true' : 'false',
			esc_html( $o[1] )
		);
	}
	echo '</div></details>';
}

/**
 * Filter bar above the product grid: Size, Colour, Price and Availability dropdowns.
 * Every option is a plain link, so filters work without JavaScript and pages stay cacheable.
 */
function riveto_filter_bar() {
	$attrs = array(
		'pa_size'   => __( 'Size', 'riveto' ),
		'pa_colour' => __( 'Colour', 'riveto' ),
	);
	echo '<div class="fbar" aria-label="' . esc_attr__( 'Filter products', 'riveto' ) . '" role="region">';
	foreach ( $attrs as $tax => $label ) {
		if ( ! taxonomy_exists( $tax ) ) {
			continue;
		}
		$terms = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => true ) );
		if ( is_wp_error( $terms ) || ! $terms ) {
			continue;
		}
		if ( 'pa_size' === $tax ) {
			usort(
				$terms,
				function ( $a, $b ) {
					return (int) $a->name - (int) $b->name;
				}
			);
		}
		$opts = array();
		foreach ( $terms as $t ) {
			$opts[] = array( $t->slug, $t->name );
		}
		riveto_filter_dropdown( $label, $opts, 'filter_' . substr( $tax, 3 ) );
	}
	riveto_filter_dropdown(
		__( 'Price', 'riveto' ),
		array(
			array( 'under-3000', __( 'Under Rs 3,000', 'riveto' ) ),
			array( '3000-3500', __( 'Rs 3,000 to 3,500', 'riveto' ) ),
			array( 'over-3500', __( 'Over Rs 3,500', 'riveto' ) ),
		),
		'price',
		false
	);
	riveto_filter_dropdown(
		__( 'Availability', 'riveto' ),
		array(
			array( 'in', __( 'In stock', 'riveto' ) ),
			array( 'out', __( 'Out of stock', 'riveto' ) ),
		),
		'stock',
		false
	);
	$active = array_filter( array_keys( $_GET ), function ( $k ) { return 0 === strpos( $k, 'filter_' ) || in_array( $k, array( 'price', 'stock' ), true ); } ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( $active ) {
		$clear = remove_query_arg( array_merge( $active, array_map( function ( $k ) { return 'query_type_' . substr( $k, 7 ); }, $active ) ) );
		printf( '<a class="fclear" href="%s" rel="nofollow">%s</a>', esc_url( $clear ), esc_html__( 'Clear filters', 'riveto' ) );
	}
	echo '<div class="fsort">';
	woocommerce_catalog_ordering();
	echo '</div></div>';

	if ( is_active_sidebar( 'shop-filters' ) ) {
		echo '<details class="shop-filters"><summary>' . esc_html__( 'More filters', 'riveto' ) . '</summary><div class="shop-filters-in">';
		dynamic_sidebar( 'shop-filters' );
		echo '</div></details>';
	}
}
add_action( 'woocommerce_before_shop_loop', 'riveto_filter_bar', 25 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );

/**
 * Turn ?price=under-3000 etc. into WooCommerce's own min/max price filter.
 */
function riveto_price_filter() {
	if ( empty( $_GET['price'] ) || isset( $_GET['min_price'] ) || isset( $_GET['max_price'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	$map = array(
		'under-3000' => array( 0, 2999 ),
		'3000-3500'  => array( 3000, 3500 ),
		'over-3500'  => array( 3501, 999999 ),
	);
	$p = sanitize_key( wp_unslash( $_GET['price'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( isset( $map[ $p ] ) ) {
		$_GET['min_price'] = (string) $map[ $p ][0];
		$_GET['max_price'] = (string) $map[ $p ][1];
	}
}
add_action( 'parse_request', 'riveto_price_filter', 1 );

/**
 * Apply ?stock=in|out to shop and category pages.
 *
 * @param WP_Query $q Query.
 */
function riveto_stock_query( $q ) {
	if ( is_admin() || ! $q->is_main_query() || empty( $_GET['stock'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	if ( ! ( $q->is_post_type_archive( 'product' ) || $q->is_tax( get_object_taxonomies( 'product' ) ) ) ) {
		return;
	}
	$want = sanitize_key( wp_unslash( $_GET['stock'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$meta = (array) $q->get( 'meta_query' );
	$meta[] = array(
		'key'     => '_stock_status',
		'value'   => 'outofstock',
		'compare' => 'out' === $want ? '=' : '!=',
	);
	$q->set( 'meta_query', $meta );
}
add_action( 'pre_get_posts', 'riveto_stock_query' );

/**
 * Show every tab (description, details, reviews) as a dropdown instead of side-by-side tabs.
 * The layout is in woocommerce/single-product/tabs/tabs.php.
 */

/**
 * ?on_sale=1 on the shop page lists only discounted products (used by the "Sale" menu item).
 *
 * @param WP_Query $q Query.
 */
function riveto_on_sale_query( $q ) {
	if ( is_admin() || ! $q->is_main_query() || empty( $_GET['on_sale'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	if ( ! ( $q->is_post_type_archive( 'product' ) || $q->is_tax( get_object_taxonomies( 'product' ) ) ) ) {
		return;
	}
	$ids = wc_get_product_ids_on_sale();
	$q->set( 'post__in', $ids ? array_map( 'absint', $ids ) : array( 0 ) );
}
add_action( 'pre_get_posts', 'riveto_on_sale_query' );

add_filter(
	'woocommerce_page_title',
	function ( $title ) {
		if ( ! empty( $_GET['on_sale'] ) && is_shop() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return __( 'Sale', 'riveto' );
		}
		if ( is_shop() && isset( $_GET['stock'] ) && 'out' === $_GET['stock'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return __( 'Out of stock', 'riveto' );
		}
		if ( is_shop() && isset( $_GET['orderby'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$o = sanitize_key( wp_unslash( $_GET['orderby'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( 'date' === $o ) {
				return __( 'New arrivals', 'riveto' );
			}
			if ( 'popularity' === $o ) {
				return __( 'Best-sellers', 'riveto' );
			}
		}
		return $title;
	}
);

/**
 * Products for the "Trending this week" grid: Featured products first, newest to fill the gaps.
 *
 * @param int $limit How many.
 * @return WC_Product[]
 */
function riveto_trending_products( $limit = 6 ) {
	$featured = wc_get_products(
		array(
			'status'     => 'publish',
			'featured'   => true,
			'limit'      => $limit,
			'visibility' => 'catalog',
			'orderby'    => 'date',
			'order'      => 'DESC',
		)
	);
	if ( count( $featured ) < $limit ) {
		$more = wc_get_products(
			array(
				'status'     => 'publish',
				'limit'      => $limit - count( $featured ),
				'visibility' => 'catalog',
				'exclude'    => array_map(
					function ( $p ) {
						return $p->get_id();
					},
					$featured
				),
				'orderby'    => 'date',
				'order'      => 'DESC',
			)
		);
		$featured = array_merge( $featured, $more );
	}
	return $featured;
}

/**
 * Product photo for home cards, or the drawn placeholder when a product has no photo yet.
 *
 * @param WC_Product $product Product.
 * @param string     $size    Image size.
 * @param int        $n       Index, used to vary placeholders.
 * @return string HTML.
 */
function riveto_product_image( $product, $size = 'riveto-card', $n = 0 ) {
	$id = $product->get_image_id();
	if ( $id ) {
		return wp_get_attachment_image( $id, $size, false, array( 'alt' => $product->get_name(), 'class' => 'rv-img' ) );
	}
	$art = array( 'hero-1-2', 'hero-1-1', 'hero-2-2', 'hero-1-3', 'hero-3-3', 'hero-2-3' );
	return sprintf(
		'<img class="rv-art" src="%s" alt="%s" width="216" height="468" loading="lazy" decoding="async">',
		esc_url( RIVETO_URI . '/assets/img/' . $art[ $n % count( $art ) ] . '.svg' ),
		esc_attr( $product->get_name() )
	);
}

/**
 * Latest approved product reviews that have a star rating.
 *
 * @param int $limit How many.
 * @return WP_Comment[]
 */
function riveto_latest_reviews( $limit = 3 ) {
	if ( 'yes' !== get_option( 'woocommerce_enable_reviews', 'yes' ) ) {
		return array();
	}
	return get_comments(
		array(
			'post_type'  => 'product',
			'status'     => 'approve',
			'type'       => 'review',
			'number'     => $limit,
			'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'     => 'rating',
					'value'   => 4,
					'compare' => '>=',
					'type'    => 'NUMERIC',
				),
			),
		)
	);
}


/**
 * Products without a photo yet show a drawn pair of trousers instead of a blank box.
 *
 * @param string     $html        Image HTML.
 * @param WC_Product $product     Product.
 * @param string     $size        Size.
 * @param array      $attr        Attributes.
 * @param bool       $placeholder Whether a placeholder is allowed.
 * @return string
 */
function riveto_placeholder_art( $html, $product, $size = '', $attr = array(), $placeholder = true ) {
	if ( ! $placeholder || ! $product || $product->get_image_id() ) {
		return $html;
	}
	$parent = $product->get_parent_id() ? wc_get_product( $product->get_parent_id() ) : null;
	if ( $parent && $parent->get_image_id() ) {
		return $html;
	}
	$slugs = wp_get_post_terms( $parent ? $parent->get_id() : $product->get_id(), 'product_cat', array( 'fields' => 'slugs' ) );
	$slugs = is_wp_error( $slugs ) ? '' : implode( ' ', $slugs );
	$art   = 'hero-1-2';
	$tone  = 'ph-blue';
	if ( false !== strpos( $slugs, 'women' ) ) {
		$art = 'hero-1-1';
		$tone = 'ph-rose';
	} elseif ( false !== strpos( $slugs, 'cargo' ) ) {
		$art = 'hero-2-1';
		$tone = 'ph-sage';
	} elseif ( false !== strpos( $slugs, 'chino' ) ) {
		$art = 'hero-3-1';
		$tone = 'ph-sand';
	}
	return sprintf(
		'<span class="rv-ph %s"><img class="rv-art" src="%s" alt="%s" width="216" height="468" loading="lazy" decoding="async"></span>',
		esc_attr( $tone ),
		esc_url( RIVETO_URI . '/assets/img/' . $art . '.svg' ),
		esc_attr( $product->get_name() )
	);
}
add_filter( 'woocommerce_product_get_image', 'riveto_placeholder_art', 10, 5 );

/**
 * Put Men and Women first when the owner has not ordered categories by hand.
 *
 * @param WP_Term[] $terms Terms.
 * @return WP_Term[]
 */
function riveto_sort_cats( $terms ) {
	if ( ! is_array( $terms ) ) {
		return $terms;
	}
	$pref = array( 'men' => 0, 'women' => 1 );
	usort(
		$terms,
		function ( $a, $b ) use ( $pref ) {
			$oa = (int) get_term_meta( $a->term_id, 'order', true );
			$ob = (int) get_term_meta( $b->term_id, 'order', true );
			if ( $oa !== $ob ) {
				return $oa - $ob;
			}
			$pa = isset( $pref[ $a->slug ] ) ? $pref[ $a->slug ] : 9;
			$pb = isset( $pref[ $b->slug ] ) ? $pref[ $b->slug ] : 9;
			return $pa !== $pb ? $pa - $pb : strcmp( $a->name, $b->name );
		}
	);
	return $terms;
}


/**
 * Product page: same drawn placeholder when the product has no photo yet.
 *
 * @param string $html          Gallery image HTML.
 * @param int    $attachment_id Attachment ID.
 * @return string
 */
function riveto_gallery_placeholder( $html, $attachment_id ) {
	if ( $attachment_id || false === strpos( $html, 'woocommerce-product-gallery__image--placeholder' ) ) {
		return $html;
	}
	global $product;
	if ( ! $product ) {
		return $html;
	}
	return '<div class="woocommerce-product-gallery__image--placeholder">' . riveto_placeholder_art( '', $product ) . '</div>';
}
add_filter( 'woocommerce_single_product_image_thumbnail_html', 'riveto_gallery_placeholder', 10, 2 );

/**
 * Show "Rs" instead of the "₨" sign, which most Pakistani shoppers read more easily.
 *
 * @param string $symbol   Symbol.
 * @param string $currency Currency code.
 * @return string
 */
function riveto_currency_symbol( $symbol, $currency ) {
	return 'PKR' === $currency ? 'Rs ' : $symbol;
}
add_filter( 'woocommerce_currency_symbol', 'riveto_currency_symbol', 10, 2 );


/**
 * Quick add under each product card: tap a size and it goes straight into the cart.
 * Simple products get one "Add to cart" button; sold-out products get a WhatsApp link instead.
 */
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );

function riveto_quick_add() {
	global $product;
	if ( ! $product ) {
		return;
	}
	echo '<div class="quick-add' . ( $product->is_in_stock() ? '' : ' is-sold' ) . '"><div class="qa-panel">';
	if ( ! $product->is_in_stock() ) {
		$wa = riveto_whatsapp_link();
		if ( $wa ) {
			/* translators: %s: product name */
			$msg = sprintf( __( 'Hi! Please tell me when %s is back in stock.', 'riveto' ), $product->get_name() );
			printf( '<a class="qa-notify" href="%s" target="_blank" rel="noopener nofollow">%s</a>', esc_url( add_query_arg( 'text', rawurlencode( $msg ), $wa ) ), esc_html__( 'Sold out · Tell me when it is back', 'riveto' ) );
		} else {
			echo '<span class="qa-sold">' . esc_html__( 'Sold out', 'riveto' ) . '</span>';
		}
		echo '</div></div>';
		return;
	}
	if ( $product->is_type( 'variable' ) ) {
		$by_size = array();
		$colour  = '';
		foreach ( $product->get_available_variations( 'objects' ) as $v ) {
			if ( ! $v || ! $v->is_in_stock() || ! $v->is_purchasable() ) {
				continue;
			}
			$atts = $v->get_attributes();
			$size = isset( $atts['pa_size'] ) ? $atts['pa_size'] : '';
			if ( '' === $size || isset( $by_size[ $size ] ) ) {
				continue;
			}
			$col = isset( $atts['pa_colour'] ) ? $atts['pa_colour'] : '';
			if ( '' === $colour ) {
				$colour = $col;
			}
			// Prefer the product's first colour so the chips match the photo.
			if ( $col === $colour ) {
				$by_size[ $size ] = $v;
			}
		}
		if ( ! $by_size ) {
			printf( '<a class="qa-options" href="%s">%s</a>', esc_url( $product->get_permalink() ), esc_html__( 'Choose options', 'riveto' ) );
			echo '</div></div>';
			return;
		}
		uksort(
			$by_size,
			function ( $a, $b ) {
				return (int) $a - (int) $b;
			}
		);
		$col_term = $colour ? get_term_by( 'slug', $colour, 'pa_colour' ) : null;
		echo '<span class="qa-label">' . esc_html__( 'Quick add', 'riveto' );
		if ( $col_term ) {
			echo ' <small>' . esc_html( $col_term->name ) . '</small>';
		}
		echo '</span><span class="qa-sizes">';
		foreach ( $by_size as $size => $v ) {
			$term = get_term_by( 'slug', $size, 'pa_size' );
			$name = $term ? $term->name : $size;
			printf(
				'<a href="%1$s" data-quantity="1" class="qa-size add_to_cart_button ajax_add_to_cart" data-product_id="%2$d" data-product_sku="%3$s" aria-label="%4$s" rel="nofollow">%5$s</a>',
				esc_url( $v->add_to_cart_url() ),
				(int) $v->get_id(),
				esc_attr( $v->get_sku() ),
				/* translators: 1: size, 2: product name */
				esc_attr( sprintf( __( 'Add size %1$s of %2$s to cart', 'riveto' ), $name, $product->get_name() ) ),
				esc_html( $name )
			);
		}
		echo '</span></div></div>';
		return;
	}
	woocommerce_template_loop_add_to_cart( array( 'class' => 'qa-button button add_to_cart_button' . ( $product->supports( 'ajax_add_to_cart' ) ? ' ajax_add_to_cart' : '' ) ) );
	echo '</div></div>';
}
add_action( 'woocommerce_after_shop_loop_item', 'riveto_quick_add', 10 );

/**
 * Home page Best-sellers and New arrivals only show things people can buy right now.
 * (Sold-out items have their own "Sold out, back soon" section.)
 *
 * @param array $args       Query args.
 * @param array $attributes Shortcode attributes.
 * @return array
 */
function riveto_home_in_stock( $args, $attributes ) {
	if ( ! is_front_page() || ! empty( $attributes['ids'] ) ) {
		return $args;
	}
	$args['meta_query']   = isset( $args['meta_query'] ) ? (array) $args['meta_query'] : array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
	$args['meta_query'][] = array(
		'key'     => '_stock_status',
		'value'   => 'outofstock',
		'compare' => '!=',
	);
	return $args;
}
add_filter( 'woocommerce_shortcode_products_query', 'riveto_home_in_stock', 10, 2 );
