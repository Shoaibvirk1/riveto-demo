<?php
/**
 * Speed and load handling.
 *
 * Every page a shopper sees (home, shop, product) is the same HTML for everyone, so a page cache
 * (LiteSpeed Cache on the host, plus Cloudflare in front) can serve it without touching PHP or the
 * database. The cart count is filled in by a tiny script only for visitors who have something in
 * their cart, so caching never shows one person's cart to another.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

/**
 * Remove things the store does not use.
 */
function riveto_trim_head() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
}
add_action( 'init', 'riveto_trim_head' );

/**
 * Drop block-editor CSS on pages built only from theme templates.
 */
function riveto_trim_styles() {
	$template_only = is_front_page() || ( function_exists( 'is_shop' ) && ( is_shop() || is_product_taxonomy() || is_product() ) );
	if ( $template_only ) {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
		wp_dequeue_style( 'classic-theme-styles' );
		wp_dequeue_style( 'global-styles' );
		wp_dequeue_style( 'wc-blocks-style' );
	}
	// The theme reads the cart count itself (see main.js), so the heavy fragments script is not needed.
	wp_dequeue_script( 'wc-cart-fragments' );
}
add_action( 'wp_enqueue_scripts', 'riveto_trim_styles', 100 );

/**
 * The first banner image is the largest thing on screen: load it first.
 *
 * @param array        $attr       Image attributes.
 * @param WP_Post      $attachment Attachment.
 * @param string|array $size       Size.
 * @return array
 */
function riveto_hero_priority( $attr, $attachment, $size ) {
	if ( 'riveto-hero' === $size && ! empty( $GLOBALS['riveto_first_hero'] ) ) {
		$attr['fetchpriority'] = 'high';
		$attr['loading']       = 'eager';
		$attr['decoding']      = 'async';
		$GLOBALS['riveto_first_hero'] = false;
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'riveto_hero_priority', 10, 3 );

/**
 * Slow the admin "heartbeat" so busy admin screens put less load on the server.
 *
 * @param array $settings Heartbeat settings.
 * @return array
 */
function riveto_heartbeat( $settings ) {
	$settings['interval'] = 60;
	return $settings;
}
add_filter( 'heartbeat_settings', 'riveto_heartbeat' );


/**
 * Home page: WooCommerce's general stylesheets are not needed (the theme styles the product
 * cards itself) and jQuery can wait until the end of the page. The banner background is
 * preloaded because it is the largest thing on the first screen.
 */
function riveto_home_speed() {
	if ( ! is_front_page() ) {
		return;
	}
	wp_dequeue_style( 'woocommerce-general' );
	wp_dequeue_style( 'woocommerce-layout' );
	wp_dequeue_style( 'woocommerce-smallscreen' );
	$scripts = wp_scripts();
	foreach ( array( 'jquery', 'jquery-core', 'jquery-migrate' ) as $handle ) {
		if ( isset( $scripts->registered[ $handle ] ) ) {
			$scripts->add_data( $handle, 'group', 1 );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'riveto_home_speed', 99 );

/**
 * Preload the first banner background on the home page.
 */
function riveto_preload_banner() {
	if ( is_front_page() && ! get_theme_mod( 'riveto_hero_1_image' ) ) {
		printf( '<link rel="preload" as="image" href="%s" type="image/webp" fetchpriority="high">' . "\n", esc_url( RIVETO_URI . '/assets/img/denim.webp' ) );
	}
}
add_action( 'wp_head', 'riveto_preload_banner', 1 );

/**
 * jQuery Migrate only helps very old plugins; skip it on the storefront.
 *
 * @param WP_Scripts $scripts Scripts.
 */
function riveto_no_migrate( $scripts ) {
	if ( is_admin() || ! isset( $scripts->registered['jquery'] ) ) {
		return;
	}
	$scripts->registered['jquery']->deps = array_diff( $scripts->registered['jquery']->deps, array( 'jquery-migrate' ) );
}
add_action( 'wp_default_scripts', 'riveto_no_migrate' );
