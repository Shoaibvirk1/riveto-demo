<?php
/**
 * Appearance > Customize > Riveto home.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

/**
 * Sanitize a checkbox.
 *
 * @param mixed $v Value.
 * @return int
 */
function riveto_sanitize_check( $v ) {
	return $v ? 1 : 0;
}

/**
 * Sanitize a link: allow full URLs or site paths like /shop/.
 *
 * @param string $v Value.
 * @return string
 */
function riveto_sanitize_link( $v ) {
	$v = trim( (string) $v );
	if ( '' === $v ) {
		return '';
	}
	if ( 0 === strpos( $v, '/' ) ) {
		return '/' . ltrim( preg_replace( '#[^A-Za-z0-9/_\-\.\?=&%]#', '', $v ), '/' );
	}
	return esc_url_raw( $v );
}

/**
 * Register settings and controls.
 *
 * @param WP_Customize_Manager $wp WP customizer.
 */
function riveto_customize( $wp ) {
	$d = riveto_defaults();

	$wp->add_panel(
		'riveto_home',
		array(
			'title'       => __( 'Riveto home', 'riveto' ),
			'description' => __( 'Everything on the home page: banner slides, which sections show, the slogan and footer text.', 'riveto' ),
			'priority'    => 25,
		)
	);

	/* Banner */
	$wp->add_section(
		'riveto_banner',
		array(
			'title'       => __( 'Banner slider', 'riveto' ),
			'panel'       => 'riveto_home',
			'description' => __( 'Up to 4 slides. Add a wide photo (at least 1920 × 1080) to a slide to replace the drawn jeans. Leave the title empty to hide a slide.', 'riveto' ),
		)
	);
	for ( $i = 1; $i <= 4; $i++ ) {
		$wp->add_setting( "riveto_hero_{$i}_image", array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
		$wp->add_control(
			new WP_Customize_Media_Control(
				$wp,
				"riveto_hero_{$i}_image",
				array(
					/* translators: %d: slide number */
					'label'     => sprintf( __( 'Slide %d: photo', 'riveto' ), $i ),
					'section'   => 'riveto_banner',
					'mime_type' => 'image',
				)
			)
		);
		$fields = array(
			'title'  => array( __( 'title', 'riveto' ), 'sanitize_text_field', 'text' ),
			'text'   => array( __( 'text', 'riveto' ), 'sanitize_text_field', 'textarea' ),
			'button' => array( __( 'button label', 'riveto' ), 'sanitize_text_field', 'text' ),
			'link'   => array( __( 'button link (e.g. /shop/ or a full URL)', 'riveto' ), 'riveto_sanitize_link', 'text' ),
		);
		foreach ( $fields as $key => $f ) {
			$id = "riveto_hero_{$i}_{$key}";
			$wp->add_setting(
				$id,
				array(
					'default'           => $d[ "hero_{$i}_{$key}" ],
					'sanitize_callback' => $f[1],
				)
			);
			$wp->add_control(
				$id,
				array(
					/* translators: 1: slide number, 2: field name */
					'label'   => sprintf( __( 'Slide %1$d: %2$s', 'riveto' ), $i, $f[0] ),
					'section' => 'riveto_banner',
					'type'    => $f[2],
				)
			);
		}
	}
	$wp->add_setting( 'riveto_hero_seconds', array( 'default' => $d['hero_seconds'], 'sanitize_callback' => 'absint' ) );
	$wp->add_control(
		'riveto_hero_seconds',
		array(
			'label'       => __( 'Seconds per slide (0 = do not move by itself)', 'riveto' ),
			'section'     => 'riveto_banner',
			'type'        => 'number',
			'input_attrs' => array( 'min' => 0, 'max' => 20 ),
		)
	);

	/* Sections on/off */
	$wp->add_section(
		'riveto_sections',
		array(
			'title'       => __( 'Home sections', 'riveto' ),
			'panel'       => 'riveto_home',
			'description' => __( '"Trending this week" shows your Featured products (click the star next to a product in Products). Best-sellers and New arrivals fill themselves from your sales and newest products.', 'riveto' ),
		)
	);
	$toggles = array(
		'show_trending' => __( 'Trending this week', 'riveto' ),
		'show_cats'     => __( 'Shop by category', 'riveto' ),
		'show_slogan'   => __( 'Slogan band', 'riveto' ),
		'show_best'     => __( 'Best-sellers', 'riveto' ),
		'show_trust'    => __( 'Cash on Delivery / delivery / exchange strip', 'riveto' ),
		'show_new'      => __( 'New arrivals', 'riveto' ),
		'show_reviews'  => __( 'Customer reviews (only shows when you have real reviews)', 'riveto' ),
		'show_soldout'  => __( 'Sold out, back soon', 'riveto' ),
	);
	foreach ( $toggles as $key => $label ) {
		$wp->add_setting( "riveto_{$key}", array( 'default' => $d[ $key ], 'sanitize_callback' => 'riveto_sanitize_check' ) );
		$wp->add_control( "riveto_{$key}", array( 'label' => $label, 'section' => 'riveto_sections', 'type' => 'checkbox' ) );
	}

	/* Slogan */
	$wp->add_section( 'riveto_slogan', array( 'title' => __( 'Slogan', 'riveto' ), 'panel' => 'riveto_home' ) );
	$slogan = array(
		'slogan_big'    => array( __( 'Slogan', 'riveto' ), 'text' ),
		'slogan_text'   => array( __( 'Line under the slogan', 'riveto' ), 'textarea' ),
		'slogan_button' => array( __( 'Button label', 'riveto' ), 'text' ),
	);
	foreach ( $slogan as $key => $f ) {
		$wp->add_setting( "riveto_{$key}", array( 'default' => $d[ $key ], 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp->add_control( "riveto_{$key}", array( 'label' => $f[0], 'section' => 'riveto_slogan', 'type' => $f[1] ) );
	}

	/* Footer and search engines */
	$wp->add_section( 'riveto_footer', array( 'title' => __( 'Footer and Google text', 'riveto' ), 'panel' => 'riveto_home' ) );
	$wp->add_setting( 'riveto_footer_text', array( 'default' => $d['footer_text'], 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp->add_control( 'riveto_footer_text', array( 'label' => __( 'Footer text under the logo', 'riveto' ), 'section' => 'riveto_footer', 'type' => 'textarea' ) );
	$wp->add_setting( 'riveto_meta_desc', array( 'default' => $d['meta_desc'], 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp->add_control(
		'riveto_meta_desc',
		array(
			'label'       => __( 'Home page description for Google', 'riveto' ),
			'description' => __( 'About 150 characters. Used only if you have not installed Rank Math or Yoast SEO (they have their own box).', 'riveto' ),
			'section'     => 'riveto_footer',
			'type'        => 'textarea',
		)
	);
}
add_action( 'customize_register', 'riveto_customize' );
