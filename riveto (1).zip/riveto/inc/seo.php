<?php
/**
 * Search-engine basics.
 *
 * WordPress prints the <title> and canonical link, and WooCommerce prints Product and Breadcrumb
 * structured data. This file fills the remaining gaps (meta description, Open Graph for WhatsApp and
 * Facebook previews, Organization and WebSite data) but steps aside as soon as an SEO plugin such as
 * Rank Math or Yoast is active, so nothing is printed twice.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is a dedicated SEO plugin handling meta tags?
 *
 * @return bool
 */
function riveto_has_seo_plugin() {
	return defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' );
}

/**
 * Plain-text, length-limited description.
 *
 * @param string $text Raw text or HTML.
 * @return string
 */
function riveto_clean_desc( $text ) {
	$text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( strip_shortcodes( (string) $text ) ) ) );
	if ( function_exists( 'mb_strlen' ) && mb_strlen( $text ) > 158 ) {
		$text = rtrim( mb_substr( $text, 0, 155 ), " ,.;:-" ) . '…';
	}
	return $text;
}

/**
 * Work out description, image and type for the current page.
 *
 * @return array{desc:string,image:string,type:string}
 */
function riveto_page_meta() {
	$desc  = '';
	$image = '';
	$type  = 'website';

	if ( is_front_page() ) {
		$desc = riveto_mod( 'meta_desc' );
	} elseif ( function_exists( 'is_product' ) && is_product() ) {
		$product = wc_get_product( get_queried_object_id() );
		if ( $product ) {
			$desc  = $product->get_short_description() ? $product->get_short_description() : $product->get_description();
			$image = wp_get_attachment_image_url( $product->get_image_id(), 'large' );
			$type  = 'product';
		}
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$term = get_queried_object();
		$desc = term_description();
		if ( ! $desc && $term ) {
			/* translators: 1: category name, 2: site name */
			$desc = sprintf( __( 'Shop %1$s at %2$s. Cash on Delivery across Pakistan and an easy 7-day size exchange.', 'riveto' ), $term->name, get_bloginfo( 'name' ) );
		}
		if ( $term && 'product_cat' === $term->taxonomy ) {
			$thumb = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
			if ( $thumb ) {
				$image = wp_get_attachment_image_url( $thumb, 'large' );
			}
		}
	} elseif ( function_exists( 'is_shop' ) && is_shop() ) {
		/* translators: %s: site name */
		$desc = sprintf( __( 'Shop jeans, cargo pants and chinos at %s. Cash on Delivery across Pakistan.', 'riveto' ), get_bloginfo( 'name' ) );
	} elseif ( is_singular() ) {
		$post = get_queried_object();
		$desc = has_excerpt( $post ) ? get_the_excerpt( $post ) : $post->post_content;
		if ( has_post_thumbnail( $post ) ) {
			$image = get_the_post_thumbnail_url( $post, 'large' );
		}
	}

	if ( ! $image ) {
		$logo  = (int) get_theme_mod( 'custom_logo' );
		$image = $logo ? wp_get_attachment_image_url( $logo, 'full' ) : RIVETO_URI . '/assets/img/share.jpg';
	}

	return array(
		'desc'  => riveto_clean_desc( $desc ),
		'image' => $image ? $image : '',
		'type'  => $type,
	);
}

/**
 * Meta description and social preview tags.
 */
function riveto_meta_tags() {
	if ( riveto_has_seo_plugin() || is_feed() ) {
		return;
	}
	$m   = riveto_page_meta();
	$url = is_singular() ? get_permalink() : ( is_front_page() ? home_url( '/' ) : '' );

	if ( $m['desc'] ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( $m['desc'] ) );
	}
	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
	printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( $m['type'] ) );
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( wp_get_document_title() ) );
	if ( $m['desc'] ) {
		printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $m['desc'] ) );
	}
	if ( $url ) {
		printf( '<meta property="og:url" content="%s">' . "\n", esc_url( $url ) );
	}
	if ( $m['image'] ) {
		printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $m['image'] ) );
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	}
	echo '<meta property="og:locale" content="en_PK">' . "\n";
}
add_action( 'wp_head', 'riveto_meta_tags', 2 );

/**
 * Organization and WebSite (with site search) structured data on the home page.
 */
function riveto_site_schema() {
	if ( riveto_has_seo_plugin() || ! is_front_page() ) {
		return;
	}
	$logo = (int) get_theme_mod( 'custom_logo' );
	$org  = array(
		'@type' => 'Organization',
		'@id'   => home_url( '/#organization' ),
		'name'  => get_bloginfo( 'name' ),
		'url'   => home_url( '/' ),
	);
	if ( $logo ) {
		$org['logo'] = wp_get_attachment_image_url( $logo, 'full' );
	}
	$phone = riveto_whatsapp_display();
	if ( $phone ) {
		$org['contactPoint'] = array(
			'@type'             => 'ContactPoint',
			'telephone'         => '+92' . substr( preg_replace( '/\D+/', '', $phone ), 1 ),
			'contactType'       => 'customer service',
			'areaServed'        => 'PK',
			'availableLanguage' => array( 'en', 'ur' ),
		);
	}
	$site = array(
		'@type'           => 'WebSite',
		'@id'             => home_url( '/#website' ),
		'url'             => home_url( '/' ),
		'name'            => get_bloginfo( 'name' ),
		'publisher'       => array( '@id' => home_url( '/#organization' ) ),
		'potentialAction' => array(
			'@type'       => 'SearchAction',
			'target'      => home_url( '/?s={search_term_string}&post_type=product' ),
			'query-input' => 'required name=search_term_string',
		),
	);
	$data = array(
		'@context' => 'https://schema.org',
		'@graph'   => array( $org, $site ),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'riveto_site_schema', 20 );

/**
 * Keep thin pages (internal search results) out of Google.
 *
 * @param array $robots Robots directives.
 * @return array
 */
function riveto_robots( $robots ) {
	if ( ! riveto_has_seo_plugin() && is_search() ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'riveto_robots' );

/**
 * Home page title: "Brand | Slogan" when no tagline is set in Settings > General.
 *
 * @param array $parts Title parts.
 * @return array
 */
function riveto_title_parts( $parts ) {
	if ( ! riveto_has_seo_plugin() && is_front_page() && empty( $parts['tagline'] ) ) {
		$parts['tagline'] = riveto_mod( 'slogan_big' );
	}
	return $parts;
}
add_filter( 'document_title_parts', 'riveto_title_parts' );


/**
 * Canonical link for pages WordPress does not cover (home, shop, categories), so filtered and
 * sorted versions of a listing all point Google at one address.
 */
function riveto_canonical() {
	if ( riveto_has_seo_plugin() || is_singular() || is_search() || is_404() ) {
		return;
	}
	$url = '';
	if ( is_front_page() ) {
		$url = home_url( '/' );
	} elseif ( function_exists( 'is_shop' ) && is_shop() ) {
		$url = wc_get_page_permalink( 'shop' );
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$link = get_term_link( get_queried_object() );
		$url  = is_wp_error( $link ) ? '' : $link;
	}
	if ( ! $url ) {
		return;
	}
	$paged = (int) get_query_var( 'paged' );
	if ( $paged > 1 ) {
		$url = trailingslashit( $url ) . user_trailingslashit( 'page/' . $paged, 'paged' );
	}
	printf( '<link rel="canonical" href="%s">' . "\n", esc_url( $url ) );
}
add_action( 'wp_head', 'riveto_canonical', 3 );
