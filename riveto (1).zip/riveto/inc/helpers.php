<?php
/**
 * Small helpers used across templates.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

/**
 * Default home-page content. The owner changes all of it in Appearance > Customize > Riveto home.
 */
function riveto_defaults() {
	return array(
		'hero_1_title'  => 'New season denim',
		'hero_1_text'   => 'Slim, straight and wide-leg jeans in soft, sturdy cotton. From Rs 3,290.',
		'hero_1_button' => 'Shop new arrivals',
		'hero_1_link'   => '/shop/?orderby=date',
		'hero_2_title'  => 'Cargo pants for every day',
		'hero_2_text'   => 'Roomy pockets and tough cotton that keeps its shape. From Rs 2,990.',
		'hero_2_button' => 'Shop cargo',
		'hero_2_link'   => '/product-category/cargo-pants/',
		'hero_3_title'  => 'Chinos for work and weekends',
		'hero_3_text'   => 'Clean, easy trousers that go with everything. From Rs 2,790.',
		'hero_3_button' => 'Shop chinos',
		'hero_3_link'   => '/product-category/chinos-trousers/',
		'hero_4_title'  => 'Best-sellers on sale',
		'hero_4_text'   => 'Save on our most-loved jeans, while sizes last.',
		'hero_4_button' => 'Shop the sale',
		'hero_4_link'   => '/shop/?on_sale=1',
		'hero_seconds'  => 5,
		'slogan_big'    => 'Built to be lived in.',
		'slogan_text'   => 'Soft from the first wear, tough enough for the hundredth.',
		'slogan_button' => 'Explore the collection',
		'show_trending' => 1,
		'show_cats'     => 1,
		'show_slogan'   => 1,
		'show_best'     => 1,
		'show_trust'    => 1,
		'show_new'      => 1,
		'show_reviews'  => 1,
		'show_soldout'  => 1,
		'footer_text'   => 'Jeans, cargos and chinos with an easy 7-day exchange and Cash on Delivery across Pakistan.',
		'meta_desc'     => 'Jeans, cargo pants and chinos in real waist sizes. Cash on Delivery across Pakistan and an easy 7-day size exchange.',
	);
}

/**
 * Read a theme setting with its default.
 *
 * @param string $key Setting key without the riveto_ prefix.
 * @return mixed
 */
function riveto_mod( $key ) {
	$d = riveto_defaults();
	return get_theme_mod( 'riveto_' . $key, isset( $d[ $key ] ) ? $d[ $key ] : '' );
}

/**
 * Turn a setting link like "/shop/" into a full URL on this site; leave full URLs alone.
 *
 * @param string $link Link from settings.
 * @return string
 */
function riveto_link( $link ) {
	$link = trim( (string) $link );
	if ( '' === $link ) {
		return home_url( '/' );
	}
	if ( preg_match( '#^https?://#i', $link ) ) {
		return $link;
	}
	return home_url( '/' . ltrim( $link, '/' ) );
}

/**
 * Inline SVG icon. Markup is fixed, so it is safe to echo.
 *
 * @param string $name Icon name.
 * @param int    $size Pixel size.
 * @return string
 */
function riveto_icon( $name, $size = 22 ) {
	$paths = array(
		'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
		'bag'    => '<path d="M5 8h14l-1 13H6L5 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
		'cash'   => '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9.5v5M18 9.5v5"/>',
		'truck'  => '<path d="M2.5 6.5h11v9h-11zM13.5 9.5h4l3 3v3h-7"/><circle cx="6.5" cy="17" r="1.8"/><circle cx="17" cy="17" r="1.8"/>',
		'swap'   => '<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
		'chat'   => '<path d="M12 3a9 9 0 0 0-7.8 13.5L3 21l4.6-1.2A9 9 0 1 0 12 3z"/>',
		'close'  => '<path d="M6 6l12 12M18 6 6 18"/>',
		'arrow'  => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		'left'   => '<path d="m15 6-6 6 6 6"/>',
		'right'  => '<path d="m9 6 6 6-6 6"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return sprintf(
		'<svg class="ic ic-%1$s" width="%2$d" height="%2$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%3$s</svg>',
		esc_attr( $name ),
		(int) $size,
		$paths[ $name ]
	);
}

/**
 * Settings from the Store Kit plugin, when it is active.
 *
 * @param string $key     Option key.
 * @param string $default Fallback.
 * @return string
 */
function riveto_storekit( $key, $default = '' ) {
	$o = get_option( 'store_kit_options', array() );
	return ( is_array( $o ) && ! empty( $o[ $key ] ) ) ? (string) $o[ $key ] : $default;
}

/**
 * WhatsApp number as shown to people, e.g. 0300 1234567.
 *
 * @return string
 */
function riveto_whatsapp_display() {
	$n = preg_replace( '/\D+/', '', riveto_storekit( 'whatsapp' ) );
	if ( '' === $n ) {
		return '';
	}
	if ( 0 === strpos( $n, '92' ) ) {
		$n = '0' . substr( $n, 2 );
	}
	return strlen( $n ) === 11 ? substr( $n, 0, 4 ) . ' ' . substr( $n, 4 ) : $n;
}

/**
 * Link to a WhatsApp chat with the store.
 *
 * @return string
 */
function riveto_whatsapp_link() {
	$n = preg_replace( '/\D+/', '', riveto_storekit( 'whatsapp' ) );
	if ( '' === $n ) {
		return '';
	}
	if ( 0 === strpos( $n, '0' ) ) {
		$n = '92' . substr( $n, 1 );
	}
	return 'https://wa.me/' . $n;
}

/**
 * Is WooCommerce running?
 *
 * @return bool
 */
function riveto_wc() {
	return class_exists( 'WooCommerce' );
}

/**
 * Shop page URL with a fallback.
 *
 * @return string
 */
function riveto_shop_url() {
	return riveto_wc() ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
}

/**
 * Menu shown when the owner has not built one yet: New arrivals, each top category, Best-sellers, Sale, Shop all.
 */
function riveto_menu_fallback() {
	$shop  = riveto_shop_url();
	$items = array();
	$items[] = array( add_query_arg( 'orderby', 'date', $shop ), __( 'New arrivals', 'riveto' ), '' );
	if ( riveto_wc() ) {
		$cats = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => 0,
				'hide_empty' => true,
				'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
				'number'     => 6,
				'orderby'    => 'menu_order',
			)
		);
		if ( ! is_wp_error( $cats ) ) {
			$cats = function_exists( 'riveto_sort_cats' ) ? riveto_sort_cats( $cats ) : $cats;
			foreach ( $cats as $c ) {
				$items[] = array( get_term_link( $c ), $c->name, '' );
			}
		}
	}
	$items[] = array( add_query_arg( 'orderby', 'popularity', $shop ), __( 'Best-sellers', 'riveto' ), '' );
	$items[] = array( add_query_arg( 'on_sale', '1', $shop ), __( 'Sale', 'riveto' ), 'menu-sale' );
	$items[] = array( $shop, __( 'All styles', 'riveto' ), '' );

	echo '<ul class="menu">';
	foreach ( $items as $it ) {
		printf( '<li class="%s"><a href="%s">%s</a></li>', esc_attr( $it[2] ), esc_url( $it[0] ), esc_html( $it[1] ) );
	}
	echo '</ul>';
}

/**
 * Print a footer menu, or a sensible default list when none is set.
 *
 * @param string $location Menu location.
 * @param array  $fallback List of [url, label].
 */
function riveto_footer_menu( $location, $fallback ) {
	if ( has_nav_menu( $location ) ) {
		wp_nav_menu(
			array(
				'theme_location' => $location,
				'container'      => false,
				'depth'          => 1,
			)
		);
		return;
	}
	echo '<ul class="menu">';
	foreach ( $fallback as $f ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( $f[0] ), esc_html( $f[1] ) );
	}
	echo '</ul>';
}

/**
 * URL of a page by slug, or empty string.
 *
 * @param string $slug Page slug.
 * @return string
 */
function riveto_page_url( $slug ) {
	$p = get_page_by_path( $slug );
	return $p ? get_permalink( $p ) : '';
}
