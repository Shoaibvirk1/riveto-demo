<?php
/**
 * Owner-friendly additions to the WordPress admin.
 *
 * WooCommerce already provides the full admin panel (orders, products, stock, customers, coupons,
 * analytics). This adds a "Store today" box at the top of the Dashboard so the owner sees what needs
 * doing the moment they log in.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the dashboard box for people who manage the shop.
 */
function riveto_dashboard_setup() {
	if ( ! riveto_wc() || ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	wp_add_dashboard_widget( 'riveto_today', __( 'Store today', 'riveto' ), 'riveto_dashboard_widget' );

	// Put it first.
	global $wp_meta_boxes;
	if ( isset( $wp_meta_boxes['dashboard']['normal']['core']['riveto_today'] ) ) {
		$mine = array( 'riveto_today' => $wp_meta_boxes['dashboard']['normal']['core']['riveto_today'] );
		unset( $wp_meta_boxes['dashboard']['normal']['core']['riveto_today'] );
		$wp_meta_boxes['dashboard']['normal']['core'] = $mine + $wp_meta_boxes['dashboard']['normal']['core']; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	}
}
add_action( 'wp_dashboard_setup', 'riveto_dashboard_setup' );

/**
 * Dashboard box content.
 */
function riveto_dashboard_widget() {
	$today = wc_get_orders(
		array(
			'date_created' => '>=' . ( new DateTime( 'today', wp_timezone() ) )->getTimestamp(), // Midnight in the store's timezone (Settings > General).
			'limit'        => 200,
			'status'       => array( 'wc-processing', 'wc-on-hold', 'wc-completed', 'wc-pending' ),
		)
	);
	$sales = 0;
	foreach ( $today as $o ) {
		$sales += (float) $o->get_total();
	}
	$processing = function_exists( 'wc_orders_count' ) ? wc_orders_count( 'processing' ) : 0;
	$on_hold    = function_exists( 'wc_orders_count' ) ? wc_orders_count( 'on-hold' ) : 0;

	$orders_url = admin_url( 'admin.php?page=wc-orders' );
	$status_arg = 'status';
	if ( ! class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) || ! \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
		$orders_url = admin_url( 'edit.php?post_type=shop_order' );
		$status_arg = 'post_status'; // The older orders screen filters with post_status.
	}
	$tiles = array(
		array( __( 'Orders today', 'riveto' ), number_format_i18n( count( $today ) ), $orders_url ),
		array( __( 'Sales today', 'riveto' ), wp_strip_all_tags( wc_price( $sales ) ), admin_url( 'admin.php?page=wc-admin' ) ),
		array( __( 'To confirm and ship', 'riveto' ), number_format_i18n( $processing ), add_query_arg( $status_arg, 'wc-processing', $orders_url ) ),
		array( __( 'Waiting for payment (bank transfer)', 'riveto' ), number_format_i18n( $on_hold ), add_query_arg( $status_arg, 'wc-on-hold', $orders_url ) ),
	);
	echo '<div class="rv-dash">';
	foreach ( $tiles as $t ) {
		printf(
			'<a class="rv-tile" href="%s"><span class="rv-num">%s</span><span class="rv-lbl">%s</span></a>',
			esc_url( $t[2] ),
			esc_html( $t[1] ),
			esc_html( $t[0] )
		);
	}
	echo '</div><p class="rv-links">';
	$links = array(
		array( __( 'Add a product', 'riveto' ), admin_url( 'post-new.php?post_type=product' ) ),
		array( __( 'Low stock', 'riveto' ), admin_url( 'admin.php?page=wc-admin&path=%2Fanalytics%2Fstock&type=lowstock' ) ),
		array( __( 'Edit home page', 'riveto' ), admin_url( 'customize.php?autofocus[panel]=riveto_home' ) ),
		array( __( 'Coupons', 'riveto' ), admin_url( 'edit.php?post_type=shop_coupon' ) ),
		array( __( 'Store Kit settings', 'riveto' ), admin_url( 'admin.php?page=store-kit' ) ),
	);
	$out = array();
	foreach ( $links as $l ) {
		$out[] = sprintf( '<a href="%s">%s</a>', esc_url( $l[1] ), esc_html( $l[0] ) );
	}
	echo wp_kses_post( implode( ' · ', $out ) );
	echo '</p>';
	?>
	<style>
		.rv-dash{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:4px 0 12px}
		.rv-tile{display:block;padding:12px 14px;border:1px solid #dcdcde;border-radius:8px;text-decoration:none;color:#1d2327;background:#fff}
		.rv-tile:hover{border-color:#2B59C3}
		.rv-num{display:block;font-size:22px;font-weight:700;line-height:1.2}
		.rv-lbl{display:block;color:#50575e;font-size:13px}
		.rv-links{margin:0}
	</style>
	<?php
}
