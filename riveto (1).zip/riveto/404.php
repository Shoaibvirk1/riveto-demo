<?php
/**
 * Page not found.
 *
 * @package Riveto
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="main" class="wrap page-main prose" tabindex="-1">
	<h1 class="page-title"><?php esc_html_e( 'This page is not here', 'riveto' ); ?></h1>
	<p><?php esc_html_e( 'The link may be old or mistyped. Search for what you need or go back to the shop.', 'riveto' ); ?></p>
	<?php get_search_form(); ?>
	<p><a class="btn" href="<?php echo esc_url( riveto_shop_url() ); ?>"><?php esc_html_e( 'Go to the shop', 'riveto' ); ?></a></p>
</main>
<?php
get_footer();
